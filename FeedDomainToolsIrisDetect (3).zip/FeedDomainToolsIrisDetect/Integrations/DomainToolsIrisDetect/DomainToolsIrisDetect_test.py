import json
import io
import pytest

from DomainToolsIrisDetect import Client, module_test, flatten_dict, format_common_fields, format_monitor, format_block, \
    format_watch, format_ips, format_name_servers, format_mail_servers, format_risk_score_components, fetch_domains, \
    domaintools_iris_detect_get_monitors_list, domaintools_iris_detect_blocklist_domains, INTEGRATION_CONTEXT_NAME, \
    domaintools_iris_detect_ignore_domains, domaintools_iris_detect_escalate_domains, \
    domaintools_iris_detect_watch_domains, common_args, domaintools_iris_detect_get_escalated_domains, \
    domaintools_iris_detect_get_ignored_domains, domaintools_iris_detect_get_new_domains, \
    domaintools_iris_detect_get_watched_domains, domaintools_iris_detect_get_blocklist_domains

client = Client(
    username="test_user",
    api_key="test_key",
    new_domains="test_new",
    changed_domains="test_changed",
    blocked_domains="test_blocked",
    tags=["TT1", "TT2"],
    risk_score_ranges=["100-100"],
    tlp_color="RED",
    include_domain_data=True,
    verify=False,
    proxy=False,
)
format_watch_output = {'dt_domain': 'christinadianeamazonstore.com', 'dt_state': 'watched',
                       'dt_discovered_date': '2022-12-27T11:40:16.241000+00:00',
                       'dt_changed_date': '2022-12-27T12:03:05.000000+00:00', 'dt_domain_id': 'KW3yJOyKDE'}
format_block_output = {'dt_watchlist_domain_id': 'Va778eAexa', 'dt_escalation_type': 'blocked', 'dt_id': 'PBbe0Rvgw2',
                       'dt_created_date_result': '2023-01-08T06:07:33.641498+00:00',
                       'dt_updated_date': '2023-01-08T06:07:33.641498+00:00', 'dt_created_by': 'nvojjala@loginsoft.com'}
format_monitor_output = {'Monitor ID': 'QEMba8wmxo', 'Term': 'aliexpress', 'State': 'active',
                         'match_substring_variations': False, 'nameserver_exclusions': [], 'text_exclusions': [],
                         'Created Date': '2022-09-20T06:01:56.760955+00:00',
                         'Updated Date': '2022-09-20T06:02:33.358799+00:00', 'Status': 'completed',
                         'Created By': 'nvojjala@loginsoft.com'}
flatten_dict_output = {'proximity': 22, 'phishing': 74, 'malware': 54, 'spam': 32,
                       'evidence': ['domain name', 'name server', 'registrant']}
format_risk_score_components_output = {'dt_proximity_score': 22, 'dt_threat_profile_malware': 54,
                                       'dt_threat_profile_phishing': 74, 'dt_threat_profile_spam': 32,
                                       'dt_threat_profile_evidence': ['domain name', 'name server', 'registrant']}
format_common_fields_output = {'dt_domain': 'amazonhn.com', 'dt_state': 'new', 'dt_status': 'active',
                               'dt_discovered_date': '2023-01-07T03:18:40.704000+00:00',
                               'dt_changed_date': '2023-01-07T03:20:16.000000+00:00', 'dt_escalations': [],
                               'dt_risk_score': 74, 'dt_risk_status': 'full', 'dt_mx_exists': False, 'dt_tld': 'com',
                               'dt_domain_id': 'MWpVbD0x5E', 'dt_monitor_ids': ['rA7bn46jQ3'],
                               'dt_create_date': 20230106,
                               'dt_registrar': 'Hong Kong Juming Network Technology Co., Ltd.',
                               'dt_registrant_contact_email': None}
format_mail_servers_output = {'dt_mailServer_raw': None, 'dt_mailServer_1': None, 'dt_mailServer_2': None}
format_name_servers_output = {'dt_nameServer_raw': None, 'dt_nameServer_1': None, 'dt_nameServer_2': None}
format_ips_output = {'dt_ip_raw': None, 'dt_ip_address_1': None, 'dt_ip_address_2': None}
return_indicator_output = {'name': 'DomainToolsIrisDetect', 'value': 'amazonhn.com',
                           'occurred': '2023-01-07T03:18:40.704000+00:00', 'type': 'DomainToolsIrisDetect',
                           'rawJSON': {'state': 'new', 'domain': 'amazonhn.com', 'status': 'active',
                                       'discovered_date': '2023-01-07T03:18:40.704000+00:00',
                                       'changed_date': '2023-01-07T03:20:16.000000+00:00', 'risk_score': 74,
                                       'risk_score_status': 'full', 'risk_score_components': {'proximity': 22,
                                                                                              'threat_profile': {
                                                                                                  'phishing': 74,
                                                                                                  'malware': 54,
                                                                                                  'spam': 32,
                                                                                                  'evidence': [
                                                                                                      'domain name',
                                                                                                      'name server',
                                                                                                      'registrant']}},
                                       'mx_exists': False, 'tld': 'com', 'id': 'MWpVbD0x5E', 'escalations': [],
                                       'monitor_ids': ['rA7bn46jQ3'],
                                       'registrar': 'Hong Kong Juming Network Technology Co., Ltd.',
                                       'create_date': 20230106},
                           'fields': {'creation_date': '2023-01-07T03:18:40.704000+00:00',
                                      'updated_date': '2023-01-07T03:20:16.000000+00:00', 'domain_status': 'active',
                                      'domaintype': 'new', 'riskscore': 74, 'riskscorestatus': 'full',
                                      'tags': 'new_domains', 'escalations': '', 'feed_related_indicators': [],
                                      'registrant_name': 'Hong Kong Juming Network Technology Co., Ltd.',
                                      'registrant_email': '', 'name_servers': '', 'mailservers': '',
                                      'riskscorecomponents': {'proximity': 22, 'phishing': 74, 'malware': 54,
                                                              'spam': 32,
                                                              'evidence': ['domain name', 'name server', 'registrant']},
                                      'traffic_light_protocol': 'RED',
                                      'last_seen_by_source': '2023-01-07T03:20:16.000000+00:00',
                                      'first_seen_by_source': '2023-01-07T03:18:40.704000+00:00'}}
common_args_output = {
    "monitor_id": "rA7bn46jQ3",
    "tlds[]": [],
    "include_domain_data": False,
    "risk_score_ranges[]": [],
    "sort[]": [],
    "order": None,
    "mx_exists": False,
    "preview": False,
    "search": None,
}


def load_json(path):
    with io.open(path, mode='r', encoding='utf-8') as f:
        return json.loads(f.read())


INDICATOR_LIST = load_json("test_data/indicator.json")
INDICATORS_LIST = load_json("test_data/indicator.json")
INDICATOR_LIST_MONITOR = load_json("test_data/monitor.json")
INDICATOR_LIST_BLOCK = load_json("test_data/block_list.json")
INDICATOR_LIST_WATCH = load_json("test_data/watched.json")
MONITOR_INPUT_LIST = load_json("test_data/monitor_input_list.json")
POST_BLOCKED_LIST = load_json("test_data/post_blocked_list.json")
POST_ESCALATED_LIST = load_json("test_data/post_escalated_list.json")
POST_WATCHED_LIST = load_json("test_data/post_watched_list.json")
POST_IGNORED_LIST = load_json("test_data/post_ignored_list.json")
GET_NEW_DOMAIN_LIST = load_json("test_data/get_new_domain_list.json")
GET_WATCHED_DOMAIN_LIST = load_json("test_data/get_watched_domain_list.json")
GET_BLOCKED_DOMAIN_LIST = load_json("test_data/get_blocked_domain_list.json")
GET_IGNORED_DOMAIN_LIST = load_json("test_data/get_ignored_domain_list.json")
GET_ESCALATED_DOMAIN_LIST = load_json("test_data/get_escalated_domain_list.json")


def test_module_test(mocker):
    mocker.patch.object(client, "query", autospec=True)
    response = module_test(client)
    assert response == "ok"


@pytest.mark.parametrize('expected_optput', [(flatten_dict_output)])
def test_flatten_dict(expected_optput):
    nested_dict = {
        "proximity": 22,
        "threat_profile": {
            "phishing": 74,
            "malware": 54,
            "spam": 32,
            "evidence": [
                "domain name",
                "name server",
                "registrant"
            ]
        }
    }
    assert flatten_dict(nested_dict) == expected_optput


def test_get_last_run(mocker):
    mocker.patch.object(client, "get_last_run", side_effect=[""])
    response = client.get_last_run("test")
    assert response == ""


@pytest.mark.parametrize('expected_output', [return_indicator_output])
def test_return_indicator(expected_output):
    response = client.return_indicator(item=INDICATOR_LIST, name="DomainTools Iris Detect New Domains Since")
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_common_fields_output])
def test_format_common_fields(expected_output):
    response = format_common_fields(result=INDICATOR_LIST)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_mail_servers_output])
def test_format_mail_servers(expected_output):
    response = format_mail_servers(result=INDICATOR_LIST)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_name_servers_output])
def test_format_name_servers(expected_output):
    response = format_name_servers(result=INDICATOR_LIST)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_ips_output])
def test_format_ips(expected_output):
    response = format_ips(result=INDICATOR_LIST)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_monitor_output])
def test_format_monitor(expected_output):
    response = format_monitor(result=INDICATOR_LIST_MONITOR)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_block_output])
def test_format_block(expected_output):
    response = format_block(result=INDICATOR_LIST_BLOCK)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_watch_output])
def test_format_watch(expected_output):
    response = format_watch(result=INDICATOR_LIST_WATCH)
    assert response == expected_output


@pytest.mark.parametrize('expected_output', [format_risk_score_components_output])
def test_format_risk_score_components(expected_output):
    response = format_risk_score_components(result=INDICATOR_LIST)
    assert response == [expected_output]


@pytest.mark.parametrize('expected_output', [common_args_output])
def test_common_args(expected_output):
    args = {"monitor_id": "rA7bn46jQ3", "tlds": None, "include_domain_data": "False", "risk_score_ranges": None,
            "sort": None, "order": None, "mx_exists": "False", "preview": "False", "search": None}
    response = common_args(args=args)
    assert expected_output == response


def test_domaintools_iris_detect_get_escalated_domains(mocker):
    mocker.patch.object(client, 'query',
                        side_effect=[GET_ESCALATED_DOMAIN_LIST])
    args = {"include_domain_data": "True"}
    response = domaintools_iris_detect_get_escalated_domains(client, args=args)
    assert response.outputs == GET_ESCALATED_DOMAIN_LIST.get("watchlist_domains", [])
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Escalated"


def test_domaintools_iris_detect_get_blocklist_domains(mocker):
    mocker.patch.object(client, 'query',
                        side_effect=[GET_BLOCKED_DOMAIN_LIST])
    args = {"include_domain_data": "True"}
    response = domaintools_iris_detect_get_blocklist_domains(client, args=args)
    assert response.outputs == GET_BLOCKED_DOMAIN_LIST.get("watchlist_domains", [])
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Blocked"


def test_domaintools_iris_detect_get_ignored_domains(mocker):
    mocker.patch.object(client, 'query',
                        side_effect=[GET_IGNORED_DOMAIN_LIST])
    args = {"include_domain_data": "True"}
    response = domaintools_iris_detect_get_ignored_domains(client, args=args)
    assert response.outputs == GET_IGNORED_DOMAIN_LIST.get("watchlist_domains", [])
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Ignored"


def test_domaintools_iris_detect_get_watched_domains(mocker):
    mocker.patch.object(client, 'query',
                        side_effect=[GET_WATCHED_DOMAIN_LIST])
    args = {"include_domain_data": "True"}
    response = domaintools_iris_detect_get_watched_domains(client, args=args)
    assert response.outputs == GET_WATCHED_DOMAIN_LIST.get("watchlist_domains", [])
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Watched"


def test_domaintools_iris_detect_get_new_domains(mocker):
    mocker.patch.object(client, 'query',
                        side_effect=[GET_NEW_DOMAIN_LIST])
    args = {"include_domain_data": "True"}
    response = domaintools_iris_detect_get_new_domains(client, args=args)
    assert response.outputs == GET_NEW_DOMAIN_LIST.get("watchlist_domains", [])
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.New"


def test_fetch_domains(mocker):
    mocker.patch.object(client, 'fetch_domaintools_domains',
                        side_effect=[INDICATORS_LIST])
    response = fetch_domains(client)
    assert str(response) == str(True)


def test_domaintools_iris_detect_get_monitors_list(mocker):
    mocker.patch.object(client, 'query',
                        side_effect=[MONITOR_INPUT_LIST])
    response = domaintools_iris_detect_get_monitors_list(client, {})
    assert len(response.outputs) == 3
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Monitor"


def test_domaintools_iris_detect_blocklist_domains(mocker):
    mocker.patch.object(client, 'query_escalate',
                        side_effect=[POST_BLOCKED_LIST])
    response = domaintools_iris_detect_blocklist_domains(client, {})
    assert len(response.outputs) == 1
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Indicators"


def test_domaintools_iris_detect_escalate_domains(mocker):
    mocker.patch.object(client, 'query_escalate',
                        side_effect=[POST_ESCALATED_LIST])
    response = domaintools_iris_detect_escalate_domains(client, {})
    assert len(response.outputs) == 1
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Indicators"


def test_domaintools_iris_detect_watch_domains(mocker):
    mocker.patch.object(client, 'query_change',
                        side_effect=[POST_WATCHED_LIST])
    response = domaintools_iris_detect_watch_domains(client, {})
    assert len(response.outputs) == 1
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Indicators"


def test_domaintools_iris_detect_ignore_domains(mocker):
    mocker.patch.object(client, 'query_change',
                        side_effect=[POST_IGNORED_LIST])
    response = domaintools_iris_detect_ignore_domains(client, {})
    assert len(response.outputs) == 1
    assert response.outputs_prefix == f"{INTEGRATION_CONTEXT_NAME}.Indicators"
