# HYAS Insight
HYAS Insight is a threat investigation and attribution solution that uses exclusive data sources and non-traditional mechanisms to improve visibility and productivity for analysts, researchers, and investigators while increasing the accuracy of findings. HYAS Insight connects attack instances and campaigns to billions of indicators of compromise to deliver insights and visibility. With an easy-to-use user interface, transforms, and API access, HYAS Insight combines rich threat data into a powerful research and attribution solution. HYAS Insight is complemented by the HYAS Intelligence team that helps organizations to better understand the nature of the threats they face on a daily basis.

Use the HYAS Insight integration to interactively lookup PassiveDNS, DynamicDNS, WHOIS, Malware and C2 Attribution Information.

## How to get a HYAS API Key
In order to obtain a HYAS Insight API key to use with Cortex XSOAR, please contact your HYAS Insight Admin. If you are unsure who your Admin is, you can also contact HYAS Support via email at support@hyas.com, by visiting the HYAS website https://www.hyas.com/contact, or by using the HYAS Insight web UI by clicking the ‘help’ icon at the top right of the screen, to request a key.

## Partner Contributed Integration
### Integration Author: HYAS
Support and maintenance for this integration are provided by the author. Please use the following contact details:
    **Email:** support@hyas.com
    **URL:** https://www.hyas.com/contact

## Configure HYASInsight on Cortex XSOAR

1. Navigate to **Settings** > **Integrations** > **Servers & Services**.
2. Search for HYASInsight.
3. Click **Add instance** to create and configure a new integration instance.

    | **Parameter** | **Required** |
    | --- | --- |
    | HYAS Insight Api Key | True |
    | Trust any certificate (not secure) | False |
    | Use system proxy settings | False |

4. Click **Test** to validate the URLs, token, and connection.
## Commands
You can execute these commands from the Cortex XSOAR CLI, as part of an automation, or in a playbook.
After you successfully execute a command, a DBot message appears in the War Room with the command details.
### hyas-get-passive-dns-records-by-indicator
***
Returns PassiveDNS records for the provided indicator value.


#### Base Command

`hyas-get-passive-dns-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ipv4, domain. | Required | 
| indicator_value | Indicator value to query. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.PassiveDNS.count | Number | The passive dns count | 
| HYAS.PassiveDNS.domain | String | The domain of the passive dns information requested | 
| HYAS.PassiveDNS.first_seen | Date | The first time this domain was seen | 
| HYAS.PassiveDNS.ip.geo.city_name | String | City of the ip organization | 
| HYAS.PassiveDNS.ip.geo.country_iso_code | String | Country ISO code of the ip organization | 
| HYAS.PassiveDNS.ip.geo.country_name | String | Country name of the ip organization | 
| HYAS.PassiveDNS.ip.geo.location_latitude | Number | The latitude of the ip organization | 
| HYAS.PassiveDNS.ip.geo.location_longitude | Number | The longitude of the ip organization | 
| HYAS.PassiveDNS.ip.geo.postal_code | String | The longitude of the ip organization | 
| HYAS.PassiveDNS.ip.ip | String | IP of the organization | 
| HYAS.PassiveDNS.ip.isp.autonomous_system_number | String | The ASN of the ip | 
| HYAS.PassiveDNS.ip.isp.autonomous_system_organization | String | The ASO of the ip | 
| HYAS.PassiveDNS.ip.isp.ip_address | String | The IP | 
| HYAS.PassiveDNS.ip.isp.isp | String | The Internet Service Provider | 
| HYAS.PassiveDNS.ip.isp.organization | String | The ISP organization | 
| HYAS.PassiveDNS.ipv4 | String | The ipv4 address of the passive dns record | 
| HYAS.PassiveDNS.last_seen | Date | The last time this domain was seen | 
| HYAS.PassiveDNS.sources | Unknown | A list of pDNS providers which the data came from | 

#### Command example
```!hyas-get-passive-dns-records-by-indicator indicator_type="domain" indicator_value="domain.org" limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "PassiveDNS": [
            {
                "count": 296778,
                "domain": "domain.org",
                "first_seen": "2015-06-08T19:16:18Z",
                "ip": {
                    "geo": {
                        "city_name": "Boston",
                        "country_iso_code": "US",
                        "country_name": "United States",
                        "location_latitude": "42.3584",
                        "location_longitude": "-71.0598",
                        "postal_code": "02108"
                    },
                    "ip": "65.254.244.180",
                    "isp": {
                        "autonomous_system_number": "AS29873",
                        "autonomous_system_organization": "Newfold Digital, Inc.",
                        "ip_address": "65.254.244.180",
                        "isp": "Newfold Digital, Inc.",
                        "organization": "Newfold Digital, Inc."
                    }
                },
                "ipv4": "65.254.244.180",
                "last_seen": "2022-10-20T23:57:54Z",
                "sources": [
                    "hyas",
                    "farsight"
                ]
            },
            {
                "count": 62645,
                "domain": "domain.org",
                "first_seen": "2010-07-13T17:29:58Z",
                "ip": {
                    "geo": {
                        "city_name": "Tukwila",
                        "country_iso_code": "US",
                        "country_name": "United States",
                        "location_latitude": "47.4740",
                        "location_longitude": "-122.2610",
                        "postal_code": "98178"
                    },
                    "ip": "216.34.94.184",
                    "isp": {
                        "autonomous_system_number": "AS3561",
                        "autonomous_system_organization": "CenturyLink Communications, LLC",
                        "ip_address": "216.34.94.184",
                        "isp": "Dotster, Inc.",
                        "organization": "Dotster, Inc."
                    }
                },
                "ipv4": "216.34.94.184",
                "last_seen": "2015-06-08T17:50:06Z",
                "sources": [
                    "farsight"
                ]
            },
            {
                "count": 1,
                "domain": "biszhu.com.domain.org",
                "first_seen": "2017-09-05T00:00:00Z",
                "ip": {
                    "geo": {
                        "city_name": "Boston",
                        "country_iso_code": "US",
                        "country_name": "United States",
                        "location_latitude": "42.3584",
                        "location_longitude": "-71.0598",
                        "postal_code": "02108"
                    },
                    "ip": "65.254.244.180",
                    "isp": {
                        "autonomous_system_number": "AS29873",
                        "autonomous_system_organization": "Newfold Digital, Inc.",
                        "ip_address": "65.254.244.180",
                        "isp": "Newfold Digital, Inc.",
                        "organization": "Newfold Digital, Inc."
                    }
                },
                "ipv4": "65.254.244.180",
                "last_seen": "2017-09-05T00:00:00Z",
                "sources": [
                    "zetalytics"
                ]
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS PassiveDNS records for domain : domain.org
>|Count|Domain|First seen|City Name|Country Code|Country Name|Latitude|Longitude|Postal Code|IP|ISP ASN|ISP ASN Organization|ISP IP Address|ISP|ISP Organization|IPV4|Last Seen|Sources|
>|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
>| 296778 | domain.org | 2015-06-08T19:16:18Z | Boston | US | United States | 42.3584 | -71.0598 | 02108 | 65.254.244.180 | AS29873 | Newfold Digital, Inc. | 65.254.244.180 | Newfold Digital, Inc. | Newfold Digital, Inc. | 65.254.244.180 | 2022-10-20T23:57:54Z | hyas,<br/>farsight |
>| 62645 | domain.org | 2010-07-13T17:29:58Z | Tukwila | US | United States | 47.4740 | -122.2610 | 98178 | 216.34.94.184 | AS3561 | CenturyLink Communications, LLC | 216.34.94.184 | Dotster, Inc. | Dotster, Inc. | 216.34.94.184 | 2015-06-08T17:50:06Z | farsight |
>| 1 | biszhu.com.domain.org | 2017-09-05T00:00:00Z | Boston | US | United States | 42.3584 | -71.0598 | 02108 | 65.254.244.180 | AS29873 | Newfold Digital, Inc. | 65.254.244.180 | Newfold Digital, Inc. | Newfold Digital, Inc. | 65.254.244.180 | 2017-09-05T00:00:00Z | zetalytics |


### hyas-get-dynamic-dns-records-by-indicator
***
Returns DynamicDNS records for the provided indicator value.


#### Base Command

`hyas-get-dynamic-dns-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ip, domain, email. | Required | 
| indicator_value | Indicator value to query. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.DynamicDNS.a_record | String | The A record for the domain | 
| HYAS.DynamicDNS.account | String | The account holder name | 
| HYAS.DynamicDNS.created | Date | The date which the domain was created | 
| HYAS.DynamicDNS.created_ip | String | The ip address of the account holder | 
| HYAS.DynamicDNS.domain | String | The domain associated with the dynamic dns information | 
| HYAS.DynamicDNS.domain_creator_ip | String | The ip address of the domain creator | 
| HYAS.DynamicDNS.email | String | The email address connected to the domain | 

#### Command example
```!hyas-get-dynamic-dns-records-by-indicator indicator_type="ip" indicator_value="94.123.200.37" limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "DynamicDNS": [
            {
                "a_record": "94.123.200.37",
                "a_record_geo": {
                    "geo": {
                        "city_name": "Istanbul",
                        "country_iso_code": "TR",
                        "country_name": "Turkey",
                        "location_latitude": "41.0186",
                        "location_longitude": "28.9322",
                        "postal_code": "34093"
                    },
                    "isp": {
                        "autonomous_system_number": "AS12978",
                        "autonomous_system_organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "ip_address": "94.123.200.37",
                        "isp": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S."
                    }
                },
                "account": "free",
                "created": "2020-05-16T02:22:46Z",
                "created_geo": {
                    "geo": {
                        "city_name": "Istanbul",
                        "country_iso_code": "TR",
                        "country_name": "Turkey",
                        "location_latitude": "40.9888",
                        "location_longitude": "28.9169",
                        "postal_code": "34107"
                    },
                    "isp": {
                        "autonomous_system_number": "AS12978",
                        "autonomous_system_organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "ip_address": "94.123.202.138",
                        "isp": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S."
                    }
                },
                "created_ip": "94.123.202.138",
                "domain": "painkiller.duckdns.org",
                "domain_creator_geo": {
                    "geo": {
                        "city_name": "Istanbul",
                        "country_iso_code": "TR",
                        "country_name": "Turkey",
                        "location_latitude": "40.9888",
                        "location_longitude": "28.9169",
                        "postal_code": "34107"
                    },
                    "isp": {
                        "autonomous_system_number": "AS12978",
                        "autonomous_system_organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "ip_address": "94.123.202.138",
                        "isp": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S."
                    }
                },
                "domain_creator_ip": "94.123.202.138",
                "email": "exemelation@gmail.com"
            },
            {
                "a_record": "94.123.193.29",
                "a_record_geo": {
                    "geo": {
                        "city_name": "Istanbul",
                        "country_iso_code": "TR",
                        "country_name": "Turkey",
                        "location_latitude": "41.0585",
                        "location_longitude": "28.9296",
                        "postal_code": "34040"
                    },
                    "isp": {
                        "autonomous_system_number": "AS12978",
                        "autonomous_system_organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "ip_address": "94.123.193.29",
                        "isp": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S."
                    }
                },
                "account": "free",
                "created": "2021-05-28T02:21:56Z",
                "created_geo": {
                    "geo": {
                        "city_name": "Istanbul",
                        "country_iso_code": "TR",
                        "country_name": "Turkey",
                        "location_latitude": "41.0186",
                        "location_longitude": "28.9322",
                        "postal_code": "34093"
                    },
                    "isp": {
                        "autonomous_system_number": "AS12978",
                        "autonomous_system_organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "ip_address": "94.123.200.37",
                        "isp": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S.",
                        "organization": "ANDROMEDA TV DIGITAL PLATFORM ISLETMECILIGI A.S."
                    }
                },
                "created_ip": "94.123.200.37",
                "domain": "pinkmann.duckdns.org",
                "domain_creator_geo": {
                    "geo": {
                        "city_name": "Istanbul",
                        "country_iso_code": "TR",
                        "country_name": "Turkey",
                        "location_latitude": "41.0186",
                        "location_longitude": "28.9322",
                        "postal_code": "34093"
                    },
                    "isp": {
                        "autonomous_system_number": "AS16135",
                        "autonomous_system_organization": "TURKCELL ILETISIM HIZMETLERI A.S.",
                        "ip_address": "188.58.71.0",
                        "isp": "TURKCELL INTERNET",
                        "organization": "TURKCELL INTERNET"
                    }
                },
                "domain_creator_ip": "188.58.71.0",
                "email": "ysfclkbs@gmail.com"
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS DynamicDNS records for ip : 94.123.200.37
>|A Record|Account|Created Date|Account Holder IP Address|Domain|Domain Creator IP Address|Email Address|
>|---|---|---|---|---|---|---|
>| 94.123.200.37 | free | 2020-05-16T02:22:46Z | 94.123.202.138 | painkiller.duckdns.org | 94.123.202.138 | exemelation@gmail.com |
>| 94.123.193.29 | free | 2021-05-28T02:21:56Z | 94.123.200.37 | pinkmann.duckdns.org | 188.58.71.0 | ysfclkbs@gmail.com |


### hyas-get-whois-records-by-indicator
***
Returns WHOIS records for the provided indicator value.


#### Base Command

`hyas-get-whois-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: domain, email, phone. | Required | 
| indicator_value | Indicator value to query. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.WHOIS.address | Unknown | address | 
| HYAS.WHOIS.city | Unknown | city | 
| HYAS.WHOIS.country | Unknown | country | 
| HYAS.WHOIS.domain | String | The domain of the registrant | 
| HYAS.WHOIS.domain_2tld | String | The second-level domain of the registrant | 
| HYAS.WHOIS.domain_created_datetime | Date | The date and time when the whois record was created | 
| HYAS.WHOIS.domain_expires_datetime | Date | The date and time when the whois record expires | 
| HYAS.WHOIS.domain_updated_datetime | Date | The date and time when the whois record was last updated | 
| HYAS.WHOIS.email | Unknown | email | 
| HYAS.WHOIS.idn_name | String | The international domain name | 
| HYAS.WHOIS.nameserver | Unknown | nameserver | 
| HYAS.WHOIS.phone.phone | String | The phone number registrant contact in e164 format | 
| HYAS.WHOIS.phone.phone_info.carrier | String | Phone number carrier | 
| HYAS.WHOIS.phone.phone_info.country | String | Phone number country | 
| HYAS.WHOIS.phone.phone_info.geo | String | Phone number geo. Can be city, province, region or country | 
| HYAS.WHOIS.privacy_punch | Boolean | True if this record has additional information bypassing privacy protect | 
| HYAS.WHOIS.registrar | String | The domain registrar | 

#### Command example
```!hyas-get-whois-records-by-indicator indicator_type="domain" indicator_value="edubolivia.org" limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "WHOIS": [
            {
                "abuse_emails": [],
                "address": [],
                "city": [],
                "country": [
                    "BO"
                ],
                "datetime": "2021-07-15T08:00:25.296Z",
                "domain": "edubolivia.org",
                "domain_2tld": "edubolivia.org",
                "domain_created_datetime": "2010-04-08T13:24:40Z",
                "domain_expires_datetime": "2022-04-08T13:24:40Z",
                "domain_updated_datetime": "2021-03-26T13:55:53Z",
                "email": [
                    "blademaster@666.hotmail.com"
                ],
                "idn_name": null,
                "name": [
                    "pablo maldonado"
                ],
                "nameserver": [
                    "ns1.solucionesrmc.com",
                    "ns2.solucionesrmc.com"
                ],
                "organization": [],
                "phone": [],
                "privacy_punch": false,
                "registrar": "pdr ltd. d/b/a publicdomainregistry.com",
                "state": [],
                "whois_nameserver": [],
                "whois_pii": []
            },
            {
                "abuse_emails": [],
                "address": [],
                "city": [],
                "country": [],
                "datetime": "2022-10-21T04:49:24.583Z",
                "domain": "edubolivia.org",
                "domain_2tld": "edubolivia.org",
                "domain_created_datetime": "2010-04-08T13:24:40Z",
                "domain_expires_datetime": "2023-04-08T13:24:40Z",
                "domain_updated_datetime": "2022-03-29T18:22:57Z",
                "email": [],
                "idn_name": null,
                "name": [],
                "nameserver": [
                    "ns3.server-us.com",
                    "ns4.server-us.com"
                ],
                "organization": [],
                "phone": [],
                "privacy_punch": false,
                "registrar": "pdr ltd. d/b/a publicdomainregistry.com",
                "state": [],
                "whois_nameserver": [],
                "whois_pii": []
            },
            {
                "abuse_emails": [],
                "address": [],
                "city": [],
                "country": [],
                "datetime": "2022-10-21T04:49:24.584Z",
                "domain": "edubolivia.org",
                "domain_2tld": "edubolivia.org",
                "domain_created_datetime": "2010-04-08T13:24:40Z",
                "domain_expires_datetime": "2022-04-08T13:24:40Z",
                "domain_updated_datetime": "2021-10-07T14:58:54Z",
                "email": [],
                "idn_name": null,
                "name": [],
                "nameserver": [
                    "ns3.server-us.com",
                    "ns4.server-us.com"
                ],
                "organization": [],
                "phone": [],
                "privacy_punch": false,
                "registrar": "pdr ltd. d/b/a publicdomainregistry.com",
                "state": [],
                "whois_nameserver": [],
                "whois_pii": []
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS WHOIS records for domain : edubolivia.org
>|Country|Domain|Domain_2tld|Domain Created Time|Domain Expires Time|Domain Updated Time|Email Address|IDN Name|Nameserver|Privacy_punch|Registrar|
>|---|---|---|---|---|---|---|---|---|---|---|
>| BO | edubolivia.org | edubolivia.org | 2010-04-08T13:24:40Z | 2022-04-08T13:24:40Z | 2021-03-26T13:55:53Z | blademaster@666.hotmail.com | None | ns1.solucionesrmc.com,<br/>ns2.solucionesrmc.com | false | pdr ltd. d/b/a publicdomainregistry.com |
>|  | edubolivia.org | edubolivia.org | 2010-04-08T13:24:40Z | 2023-04-08T13:24:40Z | 2022-03-29T18:22:57Z |  | None | ns3.server-us.com,<br/>ns4.server-us.com | false | pdr ltd. d/b/a publicdomainregistry.com |
>|  | edubolivia.org | edubolivia.org | 2010-04-08T13:24:40Z | 2022-04-08T13:24:40Z | 2021-10-07T14:58:54Z |  | None | ns3.server-us.com,<br/>ns4.server-us.com | false | pdr ltd. d/b/a publicdomainregistry.com |


### hyas-get-whois-current-records-by-domain
***
Returns WHOIS Current records for the provided indicator value.


#### Base Command

`hyas-get-whois-current-records-by-domain`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| domain | Domain value to query. | Required | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.WHOISCurrent.abuse_emails | Unknown | abuse emails | 
| HYAS.WHOISCurrent.address | Unknown | address | 
| HYAS.WHOISCurrent.city | Unknown | city | 
| HYAS.WHOISCurrent.country | Unknown | country | 
| HYAS.WHOISCurrent.domain | String | The domain of the registrant | 
| HYAS.WHOISCurrent.domain_2tld | String | The second-level domain of the registrant | 
| HYAS.WHOISCurrent.domain_created_datetime | Date | The date and time when the whois record was created | 
| HYAS.WHOISCurrent.domain_expires_datetime | Date | The date and time when the whois record expires | 
| HYAS.WHOISCurrent.domain_updated_datetime | Date | The date and time when the whois record was last updated | 
| HYAS.WHOISCurrent.email | Unknown | email | 
| HYAS.WHOISCurrent.idn_name | String | The international domain name | 
| HYAS.WHOISCurrent.nameserver | Unknown | nameserver | 
| HYAS.WHOISCurrent.organization | Unknown | organization | 
| HYAS.WHOISCurrent.phone | Unknown | The phone number | 
| HYAS.WHOISCurrent.registrar | String | The domain registrar | 
| HYAS.WHOISCurrent.state | Unknown | The state | 

#### Command example
```!hyas-get-whois-current-records-by-domain domain="edubolivia.org"```
#### Context Example
```json
{
    "HYAS": {
        "WHOISCurrent": {
            "items": [
                {
                    "abuse_emails": [
                        "abuse@publicdomainregistry.com"
                    ],
                    "address": [],
                    "city": [],
                    "country": [
                        "Bolivia"
                    ],
                    "datetime": null,
                    "domain": "edubolivia.org",
                    "domain_2tld": "edubolivia.org",
                    "domain_created_datetime": "2010-04-08T13:24:40Z",
                    "domain_expires_datetime": "2023-04-08T13:24:40Z",
                    "domain_updated_datetime": "2022-03-29T18:22:57Z",
                    "email": [
                        "please query the rdds service of the registrar of record identified in this output for information on how to contact the registrant, admin, or tech contact of the queried domain name."
                    ],
                    "idn_name": null,
                    "name": [
                        "Redacted For Privacy\nPablo Maldonado"
                    ],
                    "nameserver": [
                        "ns3.server-us.com",
                        "ns4.server-us.com"
                    ],
                    "organization": [],
                    "phone": [
                        {
                            "phone": "REDACTED FOR PRIVACY ext. REDACTED FOR PRIVACY"
                        }
                    ],
                    "privacy_punch": false,
                    "registrar": "pdr ltd. d/b/a publicdomainregistry.com",
                    "state": [
                        "la Paz"
                    ],
                    "whois_nameserver": [
                        {
                            "domain": "ns3.server-us.com"
                        },
                        {
                            "domain": "ns4.server-us.com"
                        }
                    ],
                    "whois_pii": [
                        {
                            "email": "please query the rdds service of the registrar of record identified in this output for information on how to contact the registrant, admin, or tech contact of the queried domain name.",
                            "phone_e164": "REDACTED FOR PRIVACY ext. REDACTED FOR PRIVACY"
                        },
                        {
                            "email": "please query the rdds service of the registrar of record identified in this output for information on how to contact the registrant, admin, or tech contact of the queried domain name.",
                            "geo_country_alpha_2": "Bolivia",
                            "name": "Redacted For Privacy\nPablo Maldonado",
                            "phone_e164": "REDACTED FOR PRIVACY ext. REDACTED FOR PRIVACY",
                            "state": "la Paz"
                        }
                    ]
                }
            ],
            "source": "whois",
            "total_count": 1
        }
    }
}
```

#### Human Readable Output

>### HYAS WHOISCurrent records for domain : edubolivia.org
>|Abuse Emails|Country|Domain|Domain_2tld|Domain Created Time|Domain Expires Time|Domain Updated Time|Email Address|IDN Name|Nameserver|Phone Info|Registrar|State|
>|---|---|---|---|---|---|---|---|---|---|---|---|---|
>| abuse@publicdomainregistry.com | Bolivia | edubolivia.org | edubolivia.org | 2010-04-08T13:24:40Z | 2023-04-08T13:24:40Z | 2022-03-29T18:22:57Z | please query the rdds service of the registrar of record identified in this output for information on how to contact the registrant, admin, or tech contact of the queried domain name. | None | ns3.server-us.com,<br/>ns4.server-us.com | {'phone': 'REDACTED FOR PRIVACY ext. REDACTED FOR PRIVACY'} | pdr ltd. d/b/a publicdomainregistry.com | la Paz |


### hyas-get-malware-samples-records-by-indicator
***
Returns Malware Sample records for the provided indicator value.


#### Base Command

`hyas-get-malware-samples-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: domain, ipv4, md5. | Required | 
| indicator_value | Indicator value to query. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.MalwareSamples.datetime | Date | The date which the sample was processed | 
| HYAS.MalwareSamples.domain | String | The domain of the sample | 
| HYAS.MalwareSamples.ipv4 | String | The ipv4 of the sample | 
| HYAS.MalwareSamples.ipv6 | String | The ipv6 of the sample | 
| HYAS.MalwareSamples.md5 | String | The md5 of the sample | 
| HYAS.MalwareSamples.sha1 | String | The sha1  of the sample | 
| HYAS.MalwareSamples.sha256 | String | The sha256 of the sample | 

#### Command example
```!hyas-get-malware-samples-records-by-indicator indicator_type="domain" indicator_value="chennaigastrosurgeon.com" limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "MalwareSamples": [
            {
                "datetime": "2022-09-28",
                "domain": "chennaigastrosurgeon.com",
                "ipv4": "199.59.243.222",
                "md5": "0268fb20d9143c429138034969e06833"
            },
            {
                "datetime": "2022-09-27",
                "domain": "chennaigastrosurgeon.com",
                "ipv4": "199.59.243.222",
                "md5": "21a77bca1417deb64a2ab7df77786ded"
            },
            {
                "datetime": "2022-09-24",
                "domain": "chennaigastrosurgeon.com",
                "ipv4": "199.59.243.222",
                "md5": "953951ede4e9f706e6842fa4eb4e2e65"
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS MalwareSamples records for domain : chennaigastrosurgeon.com
>|Datetime|Domain|IPV4 Address|MD5 Value|
>|---|---|---|---|
>| 2022-09-28 | chennaigastrosurgeon.com | 199.59.243.222 | 0268fb20d9143c429138034969e06833 |
>| 2022-09-27 | chennaigastrosurgeon.com | 199.59.243.222 | 21a77bca1417deb64a2ab7df77786ded |
>| 2022-09-24 | chennaigastrosurgeon.com | 199.59.243.222 | 953951ede4e9f706e6842fa4eb4e2e65 |


### hyas-get-c2attribution-records-by-indicator
***
Return C2 Attribution records for the provided indicator value.


#### Base Command

`hyas-get-c2attribution-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ip, domain, sha256, email. | Required | 
| indicator_value | Indicator Value. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.C2_Attribution.actor_ipv4 | String | The actor ipv4 | 
| HYAS.C2_Attribution.c2_domain | String | The c2 domain | 
| HYAS.C2_Attribution.c2_ip | String | The c2 ip | 
| HYAS.C2_Attribution.c2_url | String | The C2 panel url | 
| HYAS.C2_Attribution.datetime | String | C2 Attribution datetime | 
| HYAS.C2_Attribution.email | String | The actor email | 
| HYAS.C2_Attribution.email_domain | String | The email domain | 
| HYAS.C2_Attribution.referrer_domain | String | The referrer domain | 
| HYAS.C2_Attribution.referrer_ipv4 | String | The referrer ipv4 | 
| HYAS.C2_Attribution.referrer_url | String | The referrer url | 
| HYAS.C2_Attribution.sha256 | String | The sha256 malware hash | 

#### Command example
```!hyas-get-c2attribution-records-by-indicator indicator_type=domain indicator_value=himionsa.com limit=3```
#### Context Example
```json
{
    "HYAS": {
        "C2_Attribution": {
            "actor_ipv4": "197.210.62.24",
            "c2_domain": "himionsa.com",
            "c2_ip": "89.208.229.55",
            "c2_url": "http://himionsa.com/rich/panel/pvqdq929bsx_a_d_m1n_a.php?mazm=report",
            "datetime": "2020-02-25T16:39:43Z"
        }
    }
}
```

#### Human Readable Output

>### HYAS C2_Attribution records for domain : himionsa.com
>|Actor IPv4|C2 Domain|C2 IP|C2 URL|Datetime|
>|---|---|---|---|---|
>| 197.210.44.12 | himionsa.com | 89.208.229.55 | http:<span>//</span>himionsa.com/rich/panel/pvqdq929bsx_a_d_m1n_a.php?mazm=report | 2020-02-25T21:49:27Z |
>| 197.210.62.24 | himionsa.com | 89.208.229.55 | http:<span>//</span>himionsa.com/rich/panel/pvqdq929bsx_a_d_m1n_a.php?mazm=report | 2020-02-25T16:39:48Z |
>| 197.210.62.24 | himionsa.com | 89.208.229.55 | http:<span>//</span>himionsa.com/rich/panel/pvqdq929bsx_a_d_m1n_a.php?mazm=report | 2020-02-25T16:39:43Z |


### hyas-get-passive-hash-records-by-indicator
***
Return passive hash records for the provided indicator value.


#### Base Command

`hyas-get-passive-hash-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ipv4, domain. | Required | 
| indicator_value | Indicator Value. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.Passive_Hash.domain | String | The domain of the passive hash information requested | 
| HYAS.Passive_Hash.md5_count | String | The passive dns count | 

#### Command example
```!hyas-get-passive-hash-records-by-indicator indicator_type="domain" indicator_value="edubolivia.org" limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "Passive_Hash": [
            {
                "domain": "ogsrealestate.com",
                "md5_count": 457
            },
            {
                "domain": "chennaigastrosurgeon.com",
                "md5_count": 457
            },
            {
                "domain": "wuxinewway.com",
                "md5_count": 457
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS Passive_Hash records for domain : edubolivia.org
>|Domain|MD5 Count|
>|---|---|
>| ogsrealestate.com | 457 |
>| chennaigastrosurgeon.com | 457 |
>| wuxinewway.com | 457 |


### hyas-get-ssl-certificate-records-by-indicator
***
Return SSL certificate records for the provided indicator value.


#### Base Command

`hyas-get-ssl-certificate-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ip, domain, hash. | Required | 
| indicator_value | Indicator Value. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.SSL_Certificate.ssl_certs.ip | String | The ip address associated with certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.cert_key | String | The certificate key \(sha1\) | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.expire_date | String | The expiry date of the certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issue_date | String | The issue date of the certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issuer_commonName | String | The common name that the certificate was issued from | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issuer_countryName | String | The country ISO the certificate was issued from | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issuer_localityName | String | The city where the issuer company is legally located | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issuer_organizationName | String | The organization name that issued the certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issuer_organizationalUnitName | String | The organization unit name that issued the certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.issuer_stateOrProvinceName | String | The issuer state or province | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.md5 | String | The certificate MD5 | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.serial_number | String | The certificate serial number | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.sha1 | String | The certificate sha1 | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.sha_256 | String | The certificate sha256 | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.sig_algo | String | The certificate signature algorithm | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.signature | String | The certificate signature. Signature split into multiple lines | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.ssl_version | String | The SSL version | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.subject_commonName | String | The subject name that the certificate was issued to | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.subject_countryName | String | The country the certificate was issued to | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.subject_localityName | String | The city where the subject company is legally located | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.subject_organizationName | String | The organization name that recieved the certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.subject_organizationalUnitName | String | The organization unit name that recieved the certificate | 
| HYAS.SSL_Certificate.ssl_certs.ssl_cert.timestamp | String | The certificate date and time | 

#### Command example
```!hyas-get-ssl-certificate-records-by-indicator indicator_type="ip" indicator_value=104.24.110.27 limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "SSL_Certificate": [
            {
                "geo": {
                    "geo": {
                        "city_name": "San Francisco",
                        "country_iso_code": "US",
                        "country_name": "United States",
                        "location_latitude": "37.7621",
                        "location_longitude": "-122.3971",
                        "postal_code": "94107"
                    },
                    "isp": {
                        "autonomous_system_number": "AS13335",
                        "autonomous_system_organization": "Cloudflare, Inc.",
                        "ip_address": "104.24.110.27",
                        "isp": "Cloudflare, Inc.",
                        "organization": "Cloudflare, Inc."
                    }
                },
                "ip": "104.24.110.27",
                "ssl_cert": {
                    "cert_key": "261757a2d2d31aa6dcabc27bb8b2395a207c6f52",
                    "expire_date": "2020-09-25T12:00:00Z",
                    "issue_date": "2019-09-26T00:00:00Z",
                    "issuer_commonName": "CloudFlare Inc ECC CA-2",
                    "issuer_countryName": "US",
                    "issuer_localityName": "San Francisco",
                    "issuer_organizationName": "CloudFlare, Inc.",
                    "issuer_stateOrProvinceName": "CA",
                    "md5": "89c377cd36286e287b118a8013ba2296",
                    "serial_number": "11233593787305851059064306644706338579",
                    "sha1": "261757a2d2d31aa6dcabc27bb8b2395a207c6f52",
                    "sha_256": "7118e559e93b9cf442f1c93fc9ed908f904c60d74fae82107b276b137cea5357",
                    "sig_algo": "ecdsa-with-sha256",
                    "signature": "30:46:02:21:00:b5:ea:57:27:5e:dd:87:02:2c:97:29:5c:30:6d:8b:c0:7c:f3:9f:a5:2a:b1:a4:0e:80:fe:8e:2c:06:99:51:cf:02:21:00:b7:84:72:82:b0:d2:32:3d:db:05:f8:5a:05:54:d6:4c:dd:60:f2:78:30:86:9c:24:fc:88:b3:35:9c:0d:cc:fc",
                    "ssl_version": 2,
                    "subject_commonName": "sni.cloudflaressl.com",
                    "subject_countryName": "US",
                    "subject_localityName": "San Francisco",
                    "subject_organizationName": "Cloudflare, Inc.",
                    "subject_stateOrProvinceName": "CA",
                    "timestamp": "Thu, 26 Sep 2019 23:20:31 GMT"
                }
            },
            {
                "geo": {
                    "geo": {
                        "city_name": "San Francisco",
                        "country_iso_code": "US",
                        "country_name": "United States",
                        "location_latitude": "37.7621",
                        "location_longitude": "-122.3971",
                        "postal_code": "94107"
                    },
                    "isp": {
                        "autonomous_system_number": "AS13335",
                        "autonomous_system_organization": "Cloudflare, Inc.",
                        "ip_address": "104.24.110.27",
                        "isp": "Cloudflare, Inc.",
                        "organization": "Cloudflare, Inc."
                    }
                },
                "ip": "104.24.110.27",
                "ssl_cert": {
                    "cert_key": "6b08962a18c4bde0b24219628f9eacc5d9d49bb8",
                    "expire_date": "2020-09-25T12:00:00Z",
                    "issue_date": "2019-09-26T00:00:00Z",
                    "issuer_commonName": "CloudFlare Inc ECC CA-2",
                    "issuer_countryName": "US",
                    "issuer_localityName": "San Francisco",
                    "issuer_organizationName": "CloudFlare, Inc.",
                    "issuer_stateOrProvinceName": "CA",
                    "md5": "7b5744dbf479eddacdd8bd4ff2472b76",
                    "serial_number": "19104594601242960606360645661491630021",
                    "sha1": "6b08962a18c4bde0b24219628f9eacc5d9d49bb8",
                    "sha_256": "e285d3654090d184d8ae96c1f7618916f67a36b61ddbdf0391f23868fba9b60e",
                    "sig_algo": "ecdsa-with-sha256",
                    "signature": "30:44:02:20:2c:fc:df:78:a7:a2:d7:6e:c5:dd:20:c0:d1:9e:f8:c6:3b:4b:f1:2a:3f:f5:8c:85:16:4d:15:04:ef:dd:fa:11:02:20:3a:78:41:c3:b5:49:6f:f7:9e:1a:a7:55:2e:5a:22:34:e5:36:5a:1e:ab:3c:b9:f7:10:7d:de:53:f7:2e:03:a7",
                    "ssl_version": 2,
                    "subject_commonName": "sni.cloudflaressl.com",
                    "subject_countryName": "US",
                    "subject_localityName": "San Francisco",
                    "subject_organizationName": "Cloudflare, Inc.",
                    "subject_stateOrProvinceName": "CA",
                    "timestamp": "Thu, 26 Sep 2019 22:54:24 GMT"
                }
            },
            {
                "geo": {
                    "geo": {
                        "city_name": "San Francisco",
                        "country_iso_code": "US",
                        "country_name": "United States",
                        "location_latitude": "37.7621",
                        "location_longitude": "-122.3971",
                        "postal_code": "94107"
                    },
                    "isp": {
                        "autonomous_system_number": "AS13335",
                        "autonomous_system_organization": "Cloudflare, Inc.",
                        "ip_address": "104.24.110.27",
                        "isp": "Cloudflare, Inc.",
                        "organization": "Cloudflare, Inc."
                    }
                },
                "ip": "104.24.110.27",
                "ssl_cert": {
                    "cert_key": "68427341a51e5e6c16e31476b22aad668f3ba9a9",
                    "expire_date": "2020-09-26T12:00:00Z",
                    "issue_date": "2019-09-27T00:00:00Z",
                    "issuer_commonName": "CloudFlare Inc ECC CA-2",
                    "issuer_countryName": "US",
                    "issuer_localityName": "San Francisco",
                    "issuer_organizationName": "CloudFlare, Inc.",
                    "issuer_stateOrProvinceName": "CA",
                    "md5": "955f9eeb648a107f9d5ea0459857c624",
                    "serial_number": "20824549236225101440499424298862758673",
                    "sha1": "68427341a51e5e6c16e31476b22aad668f3ba9a9",
                    "sha_256": "8e80ec54c11ee71f5e35475bc0ad7114cf47bebc72c0ea075a4b3ded4347d076",
                    "sig_algo": "ecdsa-with-sha256",
                    "signature": "30:45:02:21:00:a4:d3:b4:df:69:65:eb:d1:f6:61:8b:d4:1a:a0:c8:00:ea:84:33:bf:f8:7c:a1:d1:16:e7:bf:97:6b:52:3a:a0:02:20:55:7e:e4:13:1d:12:22:df:de:9d:85:52:86:31:73:7c:aa:1b:e8:f3:78:a8:76:ef:9c:6a:61:e3:64:2d:b2:72",
                    "ssl_version": 2,
                    "subject_commonName": "sni.cloudflaressl.com",
                    "subject_countryName": "US",
                    "subject_localityName": "San Francisco",
                    "subject_organizationName": "Cloudflare, Inc.",
                    "subject_stateOrProvinceName": "CA",
                    "timestamp": "Fri, 27 Sep 2019 05:50:46 GMT"
                }
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS SSL_Certificate records for ip : 104.24.110.27
>|Geo City Name|Geo Country ISO code|Geo Country Name|Latitude|Longitude|Postal Code|ISP Autonomous System Number|ISP Autonomous System Organization|Geo ISP|Geo ISP Organization|IP|SSL Certificate Key|Expire Date|Issue Date|Issuer Common Name|Issuer Country Name|Issuer Locality Name|Issuer Organization Name|Issuer State/Province Name|Certificate MD5|Certificate Serial Number|Certificate SHA1|Certificate SHA256|Certificate Signature Algo|Certificate SSL Version|Certificate Subject Common Name|Certificate Subject Country Name|Certificate Subject Locality Name|Certificate Subject Organization Name|Certificate Subject State/Province Name|Certificate Timestamp|
>|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
>| San Francisco | US | United States | 37.7621 | -122.3971 | 94107 | AS13335 | Cloudflare, Inc. | Cloudflare, Inc. | Cloudflare, Inc. | 104.24.110.27 | 261757a2d2d31aa6dcabc27bb8b2395a207c6f52 | 2020-09-25T12:00:00Z | 2019-09-26T00:00:00Z | CloudFlare Inc ECC CA-2 | US | San Francisco | CloudFlare, Inc. | CA | 89c377cd36286e287b118a8013ba2296 | 11233593787305851059064306644706338579 | 261757a2d2d31aa6dcabc27bb8b2395a207c6f52 | 7118e559e93b9cf442f1c93fc9ed908f904c60d74fae82107b276b137cea5357 | ecdsa-with-sha256 | 2 | sni.cloudflaressl.com | US | San Francisco | Cloudflare, Inc. | CA | Thu, 26 Sep 2019 23:20:31 GMT |
>| San Francisco | US | United States | 37.7621 | -122.3971 | 94107 | AS13335 | Cloudflare, Inc. | Cloudflare, Inc. | Cloudflare, Inc. | 104.24.110.27 | 6b08962a18c4bde0b24219628f9eacc5d9d49bb8 | 2020-09-25T12:00:00Z | 2019-09-26T00:00:00Z | CloudFlare Inc ECC CA-2 | US | San Francisco | CloudFlare, Inc. | CA | 7b5744dbf479eddacdd8bd4ff2472b76 | 19104594601242960606360645661491630021 | 6b08962a18c4bde0b24219628f9eacc5d9d49bb8 | e285d3654090d184d8ae96c1f7618916f67a36b61ddbdf0391f23868fba9b60e | ecdsa-with-sha256 | 2 | sni.cloudflaressl.com | US | San Francisco | Cloudflare, Inc. | CA | Thu, 26 Sep 2019 22:54:24 GMT |
>| San Francisco | US | United States | 37.7621 | -122.3971 | 94107 | AS13335 | Cloudflare, Inc. | Cloudflare, Inc. | Cloudflare, Inc. | 104.24.110.27 | 68427341a51e5e6c16e31476b22aad668f3ba9a9 | 2020-09-26T12:00:00Z | 2019-09-27T00:00:00Z | CloudFlare Inc ECC CA-2 | US | San Francisco | CloudFlare, Inc. | CA | 955f9eeb648a107f9d5ea0459857c624 | 20824549236225101440499424298862758673 | 68427341a51e5e6c16e31476b22aad668f3ba9a9 | 8e80ec54c11ee71f5e35475bc0ad7114cf47bebc72c0ea075a4b3ded4347d076 | ecdsa-with-sha256 | 2 | sni.cloudflaressl.com | US | San Francisco | Cloudflare, Inc. | CA | Fri, 27 Sep 2019 05:50:46 GMT |


### hyas-get-opensource-indicator-records-by-indicator
***
Return Open Source intel records for the provided indicator value.


#### Base Command

`hyas-get-opensource-indicator-records-by-indicator`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ipv4, ipv6, domain, sha1, sha256, md5. | Required | 
| indicator_value | Indicator Value. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.OS_Indicators.context | String | Additional information about source. | 
| HYAS.OS_Indicators.data | Unknown | A json blob with raw data. | 
| HYAS.OS_Indicators.datetime | String | A date-time string in RFC 3339 format. | 
| HYAS.OS_Indicators.domain | String | A domain. | 
| HYAS.OS_Indicators.domain_2tld | String | A domain_2tld. | 
| HYAS.OS_Indicators.first_seen | String | A date-time string in RFC 3339 format. | 
| HYAS.OS_Indicators.ipv4 | String | The ipv4 address. Can be a cidr. | 
| HYAS.OS_Indicators.ipv6 | String | The ipv6 address. Can be a cidr. | 
| HYAS.OS_Indicators.last_seen | String | A date-time string in RFC 3339 format. | 
| HYAS.OS_Indicators.md5 | String | The md5 value. | 
| HYAS.OS_Indicators.sha1 | String | The sha1 value. | 
| HYAS.OS_Indicators.sha256 | String | The sha256 value. | 
| HYAS.OS_Indicators.source_name | String | The source name | 
| HYAS.OS_Indicators.source_url | String | The source url | 
| HYAS.OS_Indicators.uri | String | The source uri value. | 

#### Command example
```!hyas-get-opensource-indicator-records-by-indicator indicator_type=domain indicator_value=wgeupok.com limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "OS_Indicators": [
            {
                "data": "{\n  \"map\": {\n    \"cluster_id\": 13,\n    \"correlation_score\": 0.625,\n    \"domain\": \"wgeupok.com\",\n    \"host_ips\": {\n      \"myArrayList\": [\n        \"157.56.160.177\"\n      ]\n    },\n    \"inferred_group\": {\n      \"map\": {}\n    },\n    \"nameservers\": {\n      \"myArrayList\": []\n    },\n    \"observation_window_end\": 1662580800,\n    \"observation_window_start\": 1662573600,\n    \"stub_count\": 5,\n    \"type\": \"active_domain\"\n  }\n}",
                "datetime": "2022-10-14T00:00:00.000000Z",
                "domain": "wgeupok.com",
                "domain_2tld": "wgeupok.com",
                "first_seen": "2022-09-07T18:00:00.000000Z",
                "last_seen": "2022-09-14T05:00:00.000000Z",
                "os_indicators_id": "61785e23-ed88-459f-840f-6520a7f154b1",
                "os_indicators_source_id": "18ffc622-11a8-4177-b4cf-5d6bc3f8e82a",
                "source_name": "DGA Feed"
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS OS_Indicators records for domain : wgeupok.com
>|Correlation Score|Host IP|Stub Count|Type|Date Time|Domain|Domain 2TLD|First Seen|Last Seen|Source Name|
>|---|---|---|---|---|---|---|---|---|---|
>| 0.625 | 157.56.160.177 | 5 | active_domain | 2022-10-14T00:00:00.000000Z | wgeupok.com | wgeupok.com | 2022-09-07T18:00:00.000000Z | 2022-09-14T05:00:00.000000Z | DGA Feed |


### hyas-get-device-geo-records-by-ip-address
***
Returns a list of mobile geolocation information


#### Base Command

`hyas-get-device-geo-records-by-ip-address`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| indicator_type | Indicator Type. Possible values are: ipv4, ipv6. | Required | 
| indicator_value | Indicator Value. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.Device_Geo.datetime | String | A date-time string in RFC 3339 format. | 
| HYAS.Device_Geo.device_user_agent | String | The user agent string for the device. | 
| HYAS.Device_Geo.geo_country_alpha_2 | String | The ISO 3316 alpha-2 code for the country associated with the lat/long reported. | 
| HYAS.Device_Geo.geo_horizontal_accuracy | String | The GPS horizontal accuracy. | 
| HYAS.Device_Geo.ipv4 | String | The ipv4 address assigned to the device. A device may have either or ipv4 and ipv6. | 
| HYAS.Device_Geo.ipv6 | String | The ipv6 address assigned to the device. A device may have either or ipv4 and ipv6. | 
| HYAS.Device_Geo.latitude | Number | Units are degrees on the WGS 84 spheroid. | 
| HYAS.Device_Geo.longitude | Number | Units are degrees on the WGS 84 spheroid. | 
| HYAS.Device_Geo.wifi_bssid | String | The BSSID \(MAC address\) of the wifi router that the device communicated through. | 

#### Command example
```!hyas-get-device-geo-records-by-ip-address indicator_type=ipv4 indicator_value=1.157.132.70 limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "Device_Geo": [
            {
                "datetime": "2022-03-01T16:07:07Z",
                "device_geo_id": "9120a69e-cc23-451a-a55d-4223e0cec88b",
                "device_user_agent": "15.3.1",
                "geo_country_alpha_2": "AU",
                "geo_horizontal_accuracy": 20,
                "ipv4": "1.157.132.70",
                "latitude": -33.805888,
                "longitude": 150.781879
            },
            {
                "datetime": "2022-03-01T15:46:10Z",
                "device_geo_id": "c6d36363-c966-4c94-9163-cff050fc2257",
                "device_user_agent": "15.3.1",
                "geo_country_alpha_2": "AU",
                "geo_horizontal_accuracy": 15.6,
                "ipv4": "1.157.132.70",
                "latitude": -33.805855,
                "longitude": 150.781918
            },
            {
                "datetime": "2022-03-01T15:07:46Z",
                "device_geo_id": "44442ff1-3b71-406a-963c-3ece950e11f5",
                "device_user_agent": "15.3.1",
                "geo_country_alpha_2": "AU",
                "geo_horizontal_accuracy": 15.6,
                "ipv4": "1.157.132.70",
                "latitude": -33.805855,
                "longitude": 150.781918
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS Device_Geo records for ipv4 : 1.157.132.70
>|Date Time|Device User Agent|Geo Country Alpha 2|Geo Horizontal Accuracy|IPV4|Latitude|Longitude|
>|---|---|---|---|---|---|---|
>| 2022-03-01T16:07:07Z | 15.3.1 | AU | 20.0 | 1.157.132.70 | -33 | 150 |
>| 2022-03-01T15:46:10Z | 15.3.1 | AU | 15.6 | 1.157.132.70 | -33 | 150 |
>| 2022-03-01T15:07:46Z | 15.3.1 | AU | 15.6 | 1.157.132.70 | -33 | 150 |


### hyas-get-sinkhole-records-by-ipv4-address
***
Returns sinkhole information.


#### Base Command

`hyas-get-sinkhole-records-by-ipv4-address`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| ipv4 | The ipv4 address value to query. | Required | 
| limit | The maximum number of results to return. | Optional | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.Sinkhole.count | String | The sinkhole count | 
| HYAS.Sinkhole.country_name | String | The country of the ip | 
| HYAS.Sinkhole.data_port | String | The data port | 
| HYAS.Sinkhole.datetime | String | The first seen date of the sinkhole | 
| HYAS.Sinkhole.ipv4 | String | The ipv4 of the sinkhole | 
| HYAS.Sinkhole.last_seen | String | The last seen date of the sinkhole | 
| HYAS.Sinkhole.organization_name | String | The isp organization for the ip | 
| HYAS.Sinkhole.sink_source | String | The ipv4 of the sink source | 

#### Command example
```!hyas-get-sinkhole-records-by-ipv4-address ipv4=88.218.16.156 limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "Sinkhole": [
            {
                "count": 18,
                "country_code": "NL",
                "country_name": "Netherlands",
                "data_port": 5552,
                "datetime": "2020-12-23T14:06:56Z",
                "ipv4": "88.218.16.156",
                "last_seen": "2020-12-23T14:06:56Z",
                "organization_name": "Shahkar Towse'e Tejarat Mana PJSC",
                "sink_source": "192.169.69.25"
            },
            {
                "count": 157,
                "country_code": "NL",
                "country_name": "Netherlands",
                "data_port": 5552,
                "datetime": "2020-12-23T13:59:28Z",
                "ipv4": "88.218.16.156",
                "last_seen": "2020-12-23T13:59:28Z",
                "organization_name": "Shahkar Towse'e Tejarat Mana PJSC",
                "sink_source": "192.169.69.25"
            },
            {
                "count": 160,
                "country_code": "NL",
                "country_name": "Netherlands",
                "data_port": 5552,
                "datetime": "2020-12-23T12:59:44Z",
                "ipv4": "88.218.16.156",
                "last_seen": "2020-12-23T12:59:44Z",
                "organization_name": "Shahkar Towse'e Tejarat Mana PJSC",
                "sink_source": "192.169.69.25"
            }
        ]
    }
}
```

#### Human Readable Output

>### HYAS Sinkhole records for ipv4 : 88.218.16.156
>|Count|Country Name|Data Port|Date Time|IPV4|Last Seen|Organization Name|Sink Source|
>|---|---|---|---|---|---|---|---|
>| 18 | Netherlands | 5552 | 2020-12-23T14:06:56Z | 88.218.16.156 | 2020-12-23T14:06:56Z | Shahkar Towse'e Tejarat Mana PJSC | 192.169.69.25 |
>| 157 | Netherlands | 5552 | 2020-12-23T13:59:28Z | 88.218.16.156 | 2020-12-23T13:59:28Z | Shahkar Towse'e Tejarat Mana PJSC | 192.169.69.25 |
>| 160 | Netherlands | 5552 | 2020-12-23T12:59:44Z | 88.218.16.156 | 2020-12-23T12:59:44Z | Shahkar Towse'e Tejarat Mana PJSC | 192.169.69.25 |


### hyas-get-malware-sample-information-by-hash
***
Returns malware information.


#### Base Command

`hyas-get-malware-sample-information-by-hash`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| hash | The hash value to query. | Required | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.Malware_Information.avscan_score | String | AV scan score | 
| HYAS.Malware_Information.md5 | String | MD5 Hash | 
| HYAS.Malware_Information.scan_results.av_name | String | The AV Name | 
| HYAS.Malware_Information.scan_results.def_time | String | The AV datetime | 
| HYAS.Malware_Information.scan_results.threat_found | String | The source | 
| HYAS.Malware_Information.scan_time | String | The datetime of the scan | 
| HYAS.Malware_Information.sha1 | String | The sha1 hash | 
| HYAS.Malware_Information.sha256 | String | The sha256 hash | 
| HYAS.Malware_Information.sha512 | String | The sha512 hash | 

#### Command example
```!hyas-get-malware-sample-information-by-hash hash=1d0a97c41afe5540edd0a8c1fb9a0f1c limit="3"```
#### Context Example
```json
{
    "HYAS": {
        "Malware_Information": {
            "avscan_score": "-/-",
            "md5": "1d0a97c41afe5540edd0a8c1fb9a0f1c",
            "scan_results": [],
            "scan_time": "2020-07-04T08:11:42Z",
            "sha1": "9f3ae27d3d071b1cd0a220ec2d5944cde44af91a",
            "sha256": "3e3f900e6ab9e03f93fee334d357336f8ae67633420a462d0662fd51bc5004ab",
            "sha512": "956ab65f8119e9060cc955db31284bc99e6bf82bcd1b0dfcf29457cdf61acacf884209191692f8173970c6b28128e3c79d3126fd9f50df8c71612ee9b47710f9"
        }
    }
}
```

#### Human Readable Output

>### HYAS Malware_Information records for hash : 1d0a97c41afe5540edd0a8c1fb9a0f1c
>|AV Scan Score|MD5|Scan Time|SHA1|SHA256|SHA512|
>|---|---|---|---|---|---|
>| -/- | 1d0a97c41afe5540edd0a8c1fb9a0f1c | 2020-07-04T08:11:42Z | 9f3ae27d3d071b1cd0a220ec2d5944cde44af91a | 3e3f900e6ab9e03f93fee334d357336f8ae67633420a462d0662fd51bc5004ab | 956ab65f8119e9060cc955db31284bc99e6bf82bcd1b0dfcf29457cdf61acacf884209191692f8173970c6b28128e3c79d3126fd9f50df8c71612ee9b47710f9 |


### hyas-get-associated-ips-by-hash
***
Returns associated IP's for the provided hash value.


#### Base Command

`hyas-get-associated-ips-by-hash`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| md5 | The md5 value to query. | Required | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.HASH-IP.md5 | String | The provided MD5 value | 
| HYAS.HASH-IP.ips | Unknown | Associated IPS  for the provided MD5 value | 

#### Command example
```!hyas-get-associated-ips-by-hash md5="1d0a97c41afe5540edd0a8c1fb9a0f1c"```
#### Context Example
```json
{
    "HYAS": {
        "HASH-IP": {
            "ips": [
                "106.187.43.98"
            ],
            "md5": "1d0a97c41afe5540edd0a8c1fb9a0f1c"
        }
    }
}
```

#### Human Readable Output

>### HYAS HASH-IP records for md5 : 1d0a97c41afe5540edd0a8c1fb9a0f1c
>|Associated IPs|
>|---|
>| 106.187.43.98 |


### hyas-get-associated-domains-by-hash
***
Returns associated Domain's for the provided hash value.


#### Base Command

`hyas-get-associated-domains-by-hash`
#### Input

| **Argument Name** | **Description** | **Required** |
| --- | --- | --- |
| md5 | The md5 value to query. | Required | 


#### Context Output

| **Path** | **Type** | **Description** |
| --- | --- | --- |
| HYAS.HASH-DOMAIN.domains | Unknown | Associated Domains for the provided MD5 value | 
| HYAS.HASH-DOMAIN.md5 | String | The provided MD5 value | 

#### Command example
```!hyas-get-associated-domains-by-hash md5="1d0a97c41afe5540edd0a8c1fb9a0f1c"```
#### Context Example
```json
{
    "HYAS": {
        "HASH-DOMAIN": {
            "domains": [
                "butterfly.sinip.es",
                "qwertasdfg.sinip.es",
                "butterfly.bigmoney.biz"
            ],
            "md5": "1d0a97c41afe5540edd0a8c1fb9a0f1c"
        }
    }
}
```

#### Human Readable Output

>### HYAS HASH-DOMAIN records for md5 : 1d0a97c41afe5540edd0a8c1fb9a0f1c
>|Associated Domains|
>|---|
>| butterfly.sinip.es |
>| qwertasdfg.sinip.es |
>| butterfly.bigmoney.biz |

