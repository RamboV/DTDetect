"""
DomainTools Iris Detect XSOAR Integration
"""
# noqa # pylint: disable=unused-wildcard-import
# noqa
from ast import literal_eval

import urllib3
from CommonServerPython import *  # noqa: F401

# Disable insecure warnings
urllib3.disable_warnings()

INTEGRATION_CONTEXT_NAME = 'DomainToolsIrisDetect'
DOMAINTOOLS_PARAMS = {"app_partner": "cortex_xsoar",
                      "app_name": "iris_detect_for_xsoar",
                      "app_version": "1"}
TWENTY_FOUR_HOURS = str((datetime.now() - timedelta(days=1)))
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
DEFAULT_OFFSET = 0
TIMEOUT = 60.0
RETRY = 3
DOMAINTOOLS_API_BASE_URL = "https://api.domaintools.com/"
IOC_TABLE_HEADER = "Indicators from DomainTools Iris Detect"
DOMAINTOOLS_MANAGE_WATCHLIST_ENDPOINT = "v1/iris-detect/domains/"
DOMAINTOOLS_NEW_DOMAINS_ENDPOINT = "v1/iris-detect/domains/new/"
DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT = "v1/iris-detect/domains/watched/"
DOMAINTOOLS_IGNORED_DOMAINS_ENDPOINT = "v1/iris-detect/domains/ignored/"
DOMAINTOOLS_MONITOR_DOMAINS_ENDPOINT = "v1/iris-detect/monitors/"
DOMAINTOOLS_ESCALATE_DOMAINS_ENDPOINT = "v1/iris-detect/escalations/"
ESCALATE_DOMAINS_HEADER = "Escalated Domains Information"
WATCHED_DOMAINS_HEADER = "Watched Domains Information"
IGNORE_DOMAINS_HEADER = "Ignored Domains Information"
BLOCKED_DOMAINS_HEADER = "Blocked Domains Information"
GET_LIST_ESCALATE_DOMAINS_HEADER = "Escalated Domains"
GET_LIST_WATCHED_DOMAINS_HEADER = "Watched Domains"
GET_LIST_IGNORE_DOMAINS_HEADER = "Ignored Domains"
GET_LIST_BLOCKED_DOMAINS_HEADER = "Blocked Domains"
GET_LIST_NEW_DOMAINS_HEADER = "New Domains"
GET_LIST_MONITORS_HEADER = "Monitor List"
DOMAINTOOLS_NEW_DOMAINS_INCIDENT_NAME = "DomainTools Iris Detect New Domains Since"
DOMAINTOOLS_CHANGED_DOMAINS_INCIDENT_NAME = (
    "DomainTools Iris Detect Changed Domains Since"
)
DOMAINTOOLS_BLOCKED_DOMAINS_INCIDENT_NAME = (
    "DomainTools Iris Detect Blocked Domains Since"
)
FEED_TIMESTAMPS = {
    DOMAINTOOLS_NEW_DOMAINS_ENDPOINT: "new_domain_timestamp",
    DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT: "watched_domain_stamp",
    DOMAINTOOLS_IGNORED_DOMAINS_ENDPOINT: "ignored_domain_stamp",
}
NEW_DOMAIN_TIMESTAMP = "new_domain_last_run"
CHANGED_DOMAIN_TIMESTAMP = "changed_domain_last_run"
BLOCKED_DOMAIN_TIMESTAMP = "blocked_domain_last_run"
DT_TIMESTAMP_DICT = {
    NEW_DOMAIN_TIMESTAMP: "discovered_since",
    CHANGED_DOMAIN_TIMESTAMP: "changed_since",
    BLOCKED_DOMAIN_TIMESTAMP: "escalated_since",
}
TAG = {
    DOMAINTOOLS_NEW_DOMAINS_INCIDENT_NAME: "new_domains",
    DOMAINTOOLS_BLOCKED_DOMAINS_INCIDENT_NAME: "blocked_domains",
    DOMAINTOOLS_CHANGED_DOMAINS_INCIDENT_NAME: "changed_domains",
}
DOMAIN_INCIDENT_TYPE = {
    DOMAINTOOLS_NEW_DOMAINS_INCIDENT_NAME: "DomainTools Iris Detect New Domains",
    DOMAINTOOLS_CHANGED_DOMAINS_INCIDENT_NAME: "DomainTools Iris Detect Changed Domains",
    DOMAINTOOLS_BLOCKED_DOMAINS_INCIDENT_NAME: "DomainTools Iris Detect Blocked Domains"

}
""" CLIENT CLASS """


class Client(BaseClient):
    """
    Client for DomainToolsIrisDetect RESTful API!.
    Args:
          username (str): Domaintools username.
          api_key (str): Domaintools api key.
          new_domains(str): specifies whether Do Nothing, Import Indicators Only, Create Incidents and Import Indicators
          changed_domains(str): specifies whether Do Nothing, Import Indicators Only, Create Incidents and Import
          Indicators.
          blocked_domains(str): specifies whether Do Nothing, Import Indicators Only, Create Incidents and Import
          Indicators.
          tags(list): Tags list
          risk_score_ranges(list): List of risk score ranges to filter domains by
          tlp_color(str): The Traffic Light Protocol (TLP) designation to apply to indicators fetched from the feed.
          include_domain_data(bool): specifies whether to include DomainTools Iris Detect Whois, DNS Records or not.
          verify (bool): specifies whether to verify the SSL certificate or not.
          proxy (bool): specifies if to use XSOAR proxy settings.
    """

    def __init__(
            self,
            username: str,
            api_key: str,
            new_domains,
            changed_domains,
            blocked_domains,
            tags: list,
            risk_score_ranges: list,
            tlp_color: Optional[str] = None,
            include_domain_data: Optional[bool] = None,
            verify=None,
            proxy=None,
    ):

        BaseClient.__init__(
            self,
            DOMAINTOOLS_API_BASE_URL,
            verify=verify,
            headers=DEFAULT_HEADERS,
            proxy=proxy,
            ok_codes=(200,),
        )
        self.base_url = DOMAINTOOLS_API_BASE_URL
        self.username = username
        self.api_key = api_key
        self.feed_tags = tags
        self.tlp_color = tlp_color
        self.risk_score_ranges = risk_score_ranges
        self.include_domain_data = include_domain_data
        self.new_domains = new_domains
        self.changed_domains = changed_domains
        self.blocked_domains = blocked_domains

    def query(self, end_point: str, params: dict):
        """
        Get the DomainTools Iris Detect Response.

        Args:
            end_point(str): DomainTools Iris Detect URL Endpoint.
            params(dict): DomainTools Iris Detect URL Params.

        Returns:
            response: DomainTools Iris Detect server response.
        """
        param_dict = {
            **{"api_key": self.api_key,
               "api_username": self.username},
            **DOMAINTOOLS_PARAMS

        }
        return self._http_request(
            method="GET",
            full_url=f"{self.base_url}{end_point}",
            headers=DEFAULT_HEADERS,
            params={**param_dict, **params},
            timeout=TIMEOUT,
            retries=RETRY,
        )

    def query_change(self, end_point: str, watchlist_domain_ids, state):
        """
        Changes the watch state of a list of domains by their Iris Detect domain ID.

        Args:
            end_point(str): DomainTools Iris Detect URL Endpoint.
            watchlist_domain_ids(list): List of Iris Detect domain IDs to escalate.
            state(str): Valid values are: ["watched", "ignored"].

        Returns:
            response: DomainTools Iris Detect server response.
        """

        return self._http_request(
            method="PATCH",
            headers=DEFAULT_HEADERS,
            full_url=f"{self.base_url}{end_point}",
            json_data={
                **{"watchlist_domain_ids": watchlist_domain_ids,
                   "state": state},
                **DOMAINTOOLS_PARAMS
            },
            params={"api_key": self.api_key, "api_username": self.username},
            timeout=TIMEOUT,
            retries=RETRY,
        )

    def query_escalate(self, end_point: str, watchlist_domain_ids, escalation_type):
        """
        Changes the escalation type of list of domains by their Iris Detect domain ID.

        Args:
            end_point(str): DomainTools Iris Detect URL Endpoint.
            watchlist_domain_ids(list): List of Iris Detect domain IDs to escalate.
            escalation_type(str): Valid values are: ["blocked", "google_safe"].

        Returns:
            response: DomainTools Iris Detect server response.
        """
        return self._http_request(
            method="POST",
            headers=DEFAULT_HEADERS,
            full_url=f"{self.base_url}{end_point}",
            json_data={
                **{"watchlist_domain_ids": watchlist_domain_ids,
                   "escalation_type": escalation_type},
                **DOMAINTOOLS_PARAMS
            },
            timeout=TIMEOUT,
            retries=RETRY,
            params={"api_key": self.api_key, "api_username": self.username},
        )

    def return_indicator(self, item, name):
        """
        Return the Indicator object.

        Args:
            item(dict): DomainTools Iris Detect Domain Object.
            name(str): To get Tag name for new_domains, blocked_domains, changed_domains.

        Returns:
            dict: Indicator object.
        """
        risk_score_components = (
            flatten_dict(item.get("risk_score_components"))
            if item.get("risk_score_components")
            else {}
        )
        return {
            "name": "DomainToolsIrisDetect",
            "value": item.get("domain"),
            "occurred": item.get("discovered_date"),
            "type": "DomainTools Iris Detect Domain",
            "rawJSON": dict(item),
            "fields": {
                "creation_date": f"{item.get('discovered_date')}",
                "updated_date": f"{item.get('changed_date')}",
                "domain_status": item.get("status"),
                "domaintoolsirisdetectdomaintype": item.get("state"),
                "domaintoolsirisdetectriskscore": item.get("risk_score"),
                "domaintoolsirisdetectriskscorestatus": item.get("risk_score_status"),
                "domaintoolsirisdetecttld": item.get("tld"),
                "domaintoolsirisdetectdomainid": item.get("id"),
                "tags": TAG[name],
                "domaintoolsirisdetectescalations": [
                    {
                        "escalationtype": result.get("escalation_type"),
                        "id": result.get("id"),
                        "created": result.get("created"),
                        "createdby": result.get("created_by"),
                    }
                    for result in item.get("escalations")
                ]
                if item.get("escalations")
                else "",
                "feed_related_indicators": [
                    {
                        "value": result.get("ip"),
                        "type": "ip",
                        "description": "The ip that are associated with the domain.",
                    }
                    for result in item.get("ip")
                ]
                if item.get("ip")
                else [],
                "registrant_name": item.get("registrar"),
                "registrant_email": ", ".join(item.get("registrant_contact_email"))
                if item.get("registrant_contact_email")
                else "",
                "name_servers": ", ".join(
                    map(lambda result: result["host"], item.get("name_server"))
                )
                if item.get("name_server")
                else "",
                "domaintoolsirisdetectmailservers": ", ".join(
                    map(lambda result: result["host"], item.get("mx"))
                )
                if item.get("mx")
                else "",
                "domaintoolsirisdetectriskscorecomponents": {
                    "proximity": risk_score_components.get("proximity"),
                    "phishing": risk_score_components.get("phishing"),
                    "malware": risk_score_components.get("malware"),
                    "spam": risk_score_components.get("spam"),
                    "evidence": risk_score_components.get("evidence"),
                },
                "traffic_light_protocol": self.tlp_color,
                "last_seen_by_source": item.get("changed_date"),
                "first_seen_by_source": item.get("discovered_date"),
            },
        }

    def dt_domains_into_xsoar(self, domains_list, incident_name, last_run, enable_incidents=True):
        """
        Method will create indicators, incident into XSOAR.
        Args:
            domains_list(dict): DomainTools Iris Detect Domains list Object.
            incident_name(str): incident name based on domain type.
            last_run(str): To get last run
            enable_incidents(bool): specifies whether to create incident or not.

        """
        ind = []
        indicators = []
        incidents = []
        for item in domains_list:
            try:
                ind.append(item.get("domain"))
                indicators.append(self.return_indicator(item, incident_name))
                # incidents.append({
                #     "name": f"{incident_name} {self.get_last_run(last_run)}" if self.get_last_run(
                #         last_run) else f"{incident_name} the Beginning",
                #     "rawJSON": json.dumps(item),
                #     "details": json.dumps(item),
                #     "type": DOMAIN_INCIDENT_TYPE[incident_name]
                # })
            except Exception as err:
                demisto.error(f"Could not get alert info: {err}")
        if len(indicators) > 0:
            for b in batch(indicators, batch_size=2000):
                demisto.createIndicators(b)
            demisto.info(f"Adding {len(indicators)} to demisto")
            if enable_incidents:
                incidents = [
                    {
                        "name": f"{incident_name} {self.get_last_run(last_run)}" if self.get_last_run(
                            last_run) else f"{incident_name} the beginning",
                        "details": json.dumps(ind),
                        "type": DOMAIN_INCIDENT_TYPE[incident_name]
                    }
                ]
                demisto.info(f"Adding {len(incidents)} to demisto")
                demisto.createIncidents(incidents)

    def dt_api_call(self, end_point, last_run):
        """
        This will fetch the DomainToolsIrisDetect feed.

        Args:
            end_point(str): DomainTools Iris Detect URL Endpoint.
            last_run(str): String to get last fetch.

        Returns:
            list: Domains object.
            str: creating current date time.
        """
        params = {}
        if self.get_last_run(last_run):
            params[DT_TIMESTAMP_DICT[last_run]] = self.get_last_run(last_run)
        if self.include_domain_data:
            params["include_domain_data"] = 1  # type: ignore
        if last_run == BLOCKED_DOMAIN_TIMESTAMP:
            params["escalation_types[]"] = "blocked"
        if self.risk_score_ranges:
            params["risk_score_ranges[]"] = self.risk_score_ranges
        response = self.query(end_point, params)
        results = response.get("watchlist_domains", [])
        count = response.get("count")
        params["offset"] = response.get("offset")
        while response.get("total_count") != count:
            params["offset"] += response.get("limit")
            response = self.query(end_point, params)
            count += response.get("count")
            results.extend(response.get("watchlist_domains"))
        return results, str(datetime.utcnow())

    def fetch_domaintools_domains(self):
        """
        Fetch the DomainTools Iris Detect Domains into XSOAR.
        Creating indicators, incidents based on user selection.

        """
        enable_incidents = True
        blocked_domain_last_run = new_domain_last_run = changed_domain_last_run = ""
        if self.blocked_domains:
            if self.blocked_domains == "Import Indicators Only":
                enable_incidents = False
            domains_list, blocked_domain_last_run = self.dt_api_call(
                DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT, BLOCKED_DOMAIN_TIMESTAMP
            )
            self.dt_domains_into_xsoar(
                domains_list,
                DOMAINTOOLS_BLOCKED_DOMAINS_INCIDENT_NAME, BLOCKED_DOMAIN_TIMESTAMP,
                enable_incidents,
            )

        if self.changed_domains:
            if self.changed_domains == "Import Indicators Only":
                enable_incidents = False

            domains_list, changed_domain_last_run = self.dt_api_call(
                DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT, CHANGED_DOMAIN_TIMESTAMP
            )
            self.dt_domains_into_xsoar(
                domains_list,
                DOMAINTOOLS_CHANGED_DOMAINS_INCIDENT_NAME, CHANGED_DOMAIN_TIMESTAMP,
                enable_incidents,
            )
        #
        if self.new_domains:
            if self.new_domains == "Import Indicators Only":
                enable_incidents = False

            domains_list, new_domain_last_run = self.dt_api_call(
                DOMAINTOOLS_NEW_DOMAINS_ENDPOINT, NEW_DOMAIN_TIMESTAMP
            )
            self.dt_domains_into_xsoar(
                domains_list, DOMAINTOOLS_NEW_DOMAINS_INCIDENT_NAME, NEW_DOMAIN_TIMESTAMP, enable_incidents
            )
        demisto.setIntegrationContext(
            {
                BLOCKED_DOMAIN_TIMESTAMP: blocked_domain_last_run,
                CHANGED_DOMAIN_TIMESTAMP: changed_domain_last_run,
                NEW_DOMAIN_TIMESTAMP: new_domain_last_run,
            }
        )

    @staticmethod
    def set_last_run(domain_type):
        """
        sets the last run
        Args:
            domain_type(str): Set the last run for specific domain type.

        """
        demisto.setIntegrationContext({domain_type: str(datetime.now())})
        demisto.info(f"set last_run for {domain_type}: {str(datetime.now())}")

    @staticmethod
    def get_last_run(domain_type) -> str:
        """Gets last run time
        Returns:
            last run for specific domain type.
        """
        return demisto.getIntegrationContext().get(domain_type)


def fetch_domains(client: Client):
    """
    Calling fetch_domaintools_domains.

    Args:
        client(object): Client class object.
    """
    client.fetch_domaintools_domains()
    return True


def module_test(client):
    """
    Tests API connectivity and authentication
    When 'ok' is returned it indicates the integration works like
    it is supposed to and connection to the service is successful.
    Args:
        client(Client): Client class object.
    Returns:
        Connection ok.
    """
    try:
        client.query(DOMAINTOOLS_NEW_DOMAINS_ENDPOINT, {"preview": True})
    except DemistoException as err:
        if "401" in str(err):
            return "Authorization Error: Provided api_key is not valid"
        elif "403" in str(err):
            return "Authorization Error: Provided api_key is not valid"
        raise err
    return "ok"


def format_common_fields(result):
    """
    format top level fields of Iris Detect response.
    Args:
        result(dict): Domain Object
    Returns:
        dict: formatted domain object

    """
    return {
        "dt_domain": result.get("domain"),
        "dt_state": result.get("state"),
        "dt_status": result.get("status"),
        "dt_discovered_date": result.get("discovered_date"),
        "dt_changed_date": result.get("changed_date"),
        "dt_escalations": result.get("escalations"),
        "dt_risk_score": result.get("risk_score"),
        "dt_risk_status": result.get("risk_score_status"),
        "dt_mx_exists": result.get("mx_exists"),
        "dt_tld": result.get("tld"),
        "dt_domain_id": result.get("id"),
        "dt_monitor_ids": result.get("monitor_ids"),
        "dt_create_date": result.get("create_date"),
        "dt_registrar": result.get("registrar"),
        "dt_registrant_contact_email": result.get("registrant_contact_email"),
    }


def format_monitor(result):
    """
    format top level monitor list fields of Iris Detect response.
        Args:
        result(dict): Domain Object
    Returns:
        dict: formatted domain object

    """
    return {
        "Monitor ID": result.get("id"),
        "Term": result.get("term"),
        "State": result.get("state"),
        "match_substring_variations": result.get("match_substring_variations"),
        "nameserver_exclusions": result.get("nameserver_exclusions"),
        "text_exclusions": result.get("text_exclusions"),
        "Created Date": result.get("created_date"),
        "Updated Date": result.get("updated_date"),
        "Status": result.get("status"),
        "Created By": result.get("created_by"),
    }


def format_block(result):
    """
    format blocked list fields of Iris Detect response.
    Args:
        result(dict): Domain Object
    Returns:
        dict: formatted domain object
    """
    return {
        "dt_watchlist_domain_id": result.get("watchlist_domain_id"),
        "dt_escalation_type": result.get("escalation_type"),
        "dt_id": result.get("id"),
        "dt_created_date_result": result.get("created_date"),
        "dt_updated_date": result.get("updated_date"),
        "dt_created_by": result.get("created_by"),
    }


def format_watch(result):
    """
    format watch list fields of Iris Detect response.
    Args:
        result(dict): Domain Object
    Returns:
        dict: formatted domain object
    """
    return {
        "dt_domain": result.get("domain"),
        "dt_state": result.get("state"),
        "dt_discovered_date": result.get("discovered_date"),
        "dt_changed_date": result.get("changed_date"),
        "dt_domain_id": result.get("id"),
    }


def format_ips(result):
    """
    map fields from Iris Detect ips.
    Args:
        result(dict): Domain Object
    Returns:
        dict: mapped ip object
    """
    ips = result.get("ip", [])
    output = {"dt_ip_raw": json.dumps(ips) if ips else None}

    for count in range(1, 3):
        ip_address = ips.pop() if ips else {}
        output[f"dt_ip_address_{count}"] = ip_address.get("ip")

    return output


def format_name_servers(result):
    """
    map fields from Iris Detect name servers.
    Args:
        result(dict): Domain Object
    Returns:
        dict: mapped nameserver object

    """
    name_servers = result.get("name_server", [])
    output = {"dt_nameServer_raw": json.dumps(name_servers) if name_servers else None}

    for count in range(1, 3):
        name_server = name_servers.pop() if name_servers else {}
        output[f"dt_nameServer_{count}"] = name_server.get("host")

    return output


def format_mail_servers(result):
    """
    map fields from Iris Detect mail servers.
    Args:
        result(dict): Domain Object
    Returns:
        dict: mapped mailserver object
    """
    mail_servers = result.get("mx", [])
    output = {"dt_mailServer_raw": json.dumps(mail_servers) if mail_servers else None}

    for count in range(1, 3):
        mail_server = mail_servers.pop() if mail_servers else {}
        output[f"dt_mailServer_{count}"] = mail_server.get("host")

    return output


def format_risk_score_components(result):
    """
    map fields from Iris Detect risk score components.

    Args:
        result(dict): Domain Object
    Returns:
        dict: mapped risk score components object
    """
    components = result.get("risk_score_components", {})
    threat_profile = components.get("threat_profile", {})
    return {
        "dt_proximity_score": components.get("proximity"),
        "dt_threat_profile_malware": threat_profile.get("malware"),
        "dt_threat_profile_phishing": threat_profile.get("phishing"),
        "dt_threat_profile_spam": threat_profile.get("spam"),
        "dt_threat_profile_evidence": threat_profile.get("evidence"),
    }


def flatten_dict(nested_dict: dict) -> dict:
    """
    To flatten dict.

    Args:
        nested_dict(dict): nested dict
    Returns:
        dict: flatted dict
    """

    result = {}
    for key, value in nested_dict.items():
        if isinstance(value, dict):
            result.update(flatten_dict(value))
        else:
            result[key] = value
    return result


def dt_get_results(
        client: Client, end_point: str, tb_header_name: str, dt_args: dict
) -> object:
    """
    To return ``CommandResults``

    Args:
        client(Client): Client class object
        end_point(str): DomainTools Iris Detect endpoint
        tb_header_name(str): Table header name
        dt_args(dict): args to get the filtered response from Iris Detect

    Returns:
        object: CommandResults
    """
    response = client.query(end_point, dt_args)
    if response.get("error"):
        return CommandResults(
            readable_output=(
                response.get("error").get("message") if response.get("error").get("message") else response.get(
                    "error")
            )
        )
    results = response.get("watchlist_domains", [])
    count = response.get("count")
    if count == 0:
        return CommandResults(readable_output="No Domains Found.")
    dt_args["offset"] = 0
    while response.get("total_count") != count:
        dt_args["offset"] += response.get("limit")
        response = client.query(end_point, dt_args)
        count += response.get("count")
        results.extend(response.get("watchlist_domains"))
    indicator_list = []
    for result in results:
        row = {}
        row.update(format_common_fields(result))
        row.update(format_risk_score_components(result))
        if dt_args.get("include_domain_data"):
            row.update(format_ips(result))
            row.update(format_name_servers(result))
            row.update(format_mail_servers(result))
        indicator_list.append(row)
    readable_output = tableToMarkdown(name=tb_header_name, t=indicator_list)
    return CommandResults(
        outputs=indicator_list,
        outputs_prefix=f"{INTEGRATION_CONTEXT_NAME}.Indicators",
        outputs_key_field="domain",
        readable_output=readable_output,
        raw_response=indicator_list
    )


def common_args(args: dict) -> dict:
    return {
        "monitor_id": args.get("monitor_id"),
        "tlds[]": argToList(args.get("tlds")),
        "include_domain_data": literal_eval(args.get("include_domain_data", "False")),
        "risk_score_ranges[]": argToList(args.get("risk_score_ranges")),
        "sort[]": argToList(args.get("sort")),
        "order": args.get("order"),
        "mx_exists": literal_eval(args.get("mx_exists", "False")),
        "preview": literal_eval(args.get("preview", "False")),
        "search": args.get("search"),
    }


def escalate_args(args: dict) -> dict:
    return {
        "escalated_since": args.get("escalated_since"),
        "escalation_types[]": args.get("escalation_types"),
        "changed_since": args.get("changed_since"),
        "discovered_since": args.get("discovered_since"),
    }


def domaintools_iris_detect_get_watched_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_get_watched_domains: Get the watched domains list.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    return dt_get_results(
        client,
        DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT,
        WATCHED_DOMAINS_HEADER,
        {**common_args(args), **escalate_args(args)},
    )


def domaintools_iris_detect_get_new_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_get_new_domains: Get the new domains list.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    return dt_get_results(
        client,
        DOMAINTOOLS_NEW_DOMAINS_ENDPOINT,
        GET_LIST_NEW_DOMAINS_HEADER,
        {
            **common_args(args),
            **{
                "discovered_since": args.get("discovered_since"),
                "changed_since": args.get("changed_since"),
            },
        },
    )


def domaintools_iris_detect_get_ignored_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_get_ignored_domains: Get the ignored domains list.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    return dt_get_results(
        client,
        DOMAINTOOLS_IGNORED_DOMAINS_ENDPOINT,
        IGNORE_DOMAINS_HEADER,
        {**common_args(args), **escalate_args(args)},
    )


def domaintools_iris_detect_get_blocklist_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_get_blocklist_domains: Get the blocked domains list.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    return dt_get_results(
        client,
        DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT,
        BLOCKED_DOMAINS_HEADER,
        {
            **common_args(args),
            **escalate_args(args),
            **{"escalation_types[]": "blocked"},
        },
    )


def domaintools_iris_detect_get_escalated_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_get_escalated_domains: Get the escalated domains list.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    return dt_get_results(
        client,
        DOMAINTOOLS_WATCHED_DOMAINS_ENDPOINT,
        ESCALATE_DOMAINS_HEADER,
        {
            **common_args(args),
            **escalate_args(args),
            **{"escalation_types[]": "google_safe"},
        },
    )


def domaintools_iris_detect_get_monitors_list(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_get_monitors_list: Get the monitor domains list.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    response = client.query(
        DOMAINTOOLS_MONITOR_DOMAINS_ENDPOINT,
        dt_args := {
            **{
                "datetime_counts_since": arg_to_datetime(
                    args.get("datetime_counts_since")
                )
            },
            **common_args(args),
            **escalate_args(args),
        },
    )
    if response.get("error"):
        return CommandResults(
            readable_output=(
                response.get("error").get("message") if response.get("error").get("message") else response.get(
                    "error")
            )
        )
    results = response.get("monitors", [])
    if len(results) == 0:
        return CommandResults(readable_output="No Domains Found.")
    count = len(results)
    dt_args["offset"] = DEFAULT_OFFSET  # type: ignore
    while response.get("total_count", 0) != count:
        dt_args["offset"] = dt_args["offset"] + response.get("limit")
        response = client.query(DOMAINTOOLS_MONITOR_DOMAINS_ENDPOINT, dt_args)
        count = count + len(response.get("monitors", []))
        results.extend(response.get("monitors"))
    indicator_list = []
    for result in results:
        row = {}
        row.update(format_monitor(result))
        indicator_list.append(row)
    readable_output = tableToMarkdown(name=GET_LIST_MONITORS_HEADER, t=indicator_list)
    return CommandResults(
        outputs=indicator_list,
        outputs_prefix=f"{INTEGRATION_CONTEXT_NAME}.Indicators",
        outputs_key_field="domain",
        readable_output=readable_output
    )


def domaintools_iris_detect_watch_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_watch_domains: Changes the state of a list of domains to ``watched``.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    state = "watched"
    watchlist_domain_ids = argToList(args.get("watchlist_domain_ids"))
    response = client.query_change(
        DOMAINTOOLS_MANAGE_WATCHLIST_ENDPOINT, watchlist_domain_ids, state
    )
    indicators_list = []
    if response.get("error"):
        return CommandResults(readable_output=response.get("error")["message"])
    for result in response.get("watchlist_domains"):
        row = {}
        row.update(format_watch(result))
        indicators_list.append(row)
    readable_output = tableToMarkdown(name=WATCHED_DOMAINS_HEADER, t=indicators_list)
    return CommandResults(
        outputs=indicators_list,
        outputs_prefix=f"{INTEGRATION_CONTEXT_NAME}.Indicators",
        outputs_key_field="domain",
        readable_output=readable_output,
        raw_response=indicators_list
    )


def domaintools_iris_detect_ignore_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_watch_domains: Changes the state of a list of domains to ``ignored``.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    state = "ignored"
    watchlist_domain_ids = argToList(args.get("watchlist_domain_ids"))
    response = client.query_change(
        DOMAINTOOLS_MANAGE_WATCHLIST_ENDPOINT, watchlist_domain_ids, state
    )

    if response.get("error"):
        return CommandResults(readable_output=response.json().get("error")["message"])
    indicators_list = []
    for result in response.get("watchlist_domains"):
        row = {}
        row.update(format_watch(result))
        indicators_list.append(row)
    readable_output = tableToMarkdown(
        name=IGNORE_DOMAINS_HEADER,
        t=indicators_list,
    )

    return CommandResults(
        outputs=indicators_list,
        outputs_prefix=f"{INTEGRATION_CONTEXT_NAME}.Indicators",
        outputs_key_field="domain",
        readable_output=readable_output,
        raw_response=indicators_list
    )


def domaintools_iris_detect_escalate_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_watch_domains: Changes the escalation type of list of domains to ``google_safe``.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    escalation_type = "google_safe"
    watchlist_domain_ids = argToList(args.get("watchlist_domain_ids"))
    response = client.query_escalate(
        DOMAINTOOLS_ESCALATE_DOMAINS_ENDPOINT, watchlist_domain_ids, escalation_type
    )
    results = response.get("escalations")
    if response.get("error"):
        return CommandResults(readable_output=response.json().get("error")["message"])
    indicators_list = []
    if response.get("error"):
        return CommandResults(readable_output=response.json().get("error")["message"])
    for result in results:
        row = {}
        row.update(format_block(result))
        indicators_list.append(row)
    readable_output = tableToMarkdown(
        name=ESCALATE_DOMAINS_HEADER,
        t=indicators_list,
    )

    return CommandResults(
        outputs=indicators_list,
        outputs_prefix=f"{INTEGRATION_CONTEXT_NAME}.Indicators",
        outputs_key_field="domain",
        readable_output=readable_output,
        raw_response=indicators_list
    )


def domaintools_iris_detect_blocklist_domains(client: Client, args: dict) -> object:
    """
    domaintools_iris_detect_watch_domains: Changes the escalation type of list of domains to ``blocked``.
    Args:
        client: DomainTools client to use.
        args: all command arguments, usually passed from ``demisto.args()``.
    Returns:
        dt_get_results: A ``CommandResults`` object that is then passed
         to ``return_results``, that contains result which will display in war room.
    """
    escalation_type = "blocked"
    watchlist_domain_ids = argToList(args.get("watchlist_domain_ids"))
    response = client.query_escalate(
        DOMAINTOOLS_ESCALATE_DOMAINS_ENDPOINT, watchlist_domain_ids, escalation_type
    )
    rows = []
    results = response.get("escalations")
    indicators_list = []
    if response.get("error"):
        return CommandResults(
            readable_output=(
                response.get("error").get("message") if response.get("error").get("message") else response.get(
                    "error")
            )
        )
    if results:
        for result in results:
            row = {}
            row.update(format_block(result))
            rows.append(row)
        indicators_list = rows
    readable_output = tableToMarkdown(
        name=BLOCKED_DOMAINS_HEADER, t=indicators_list
    )

    return CommandResults(
        outputs=indicators_list,
        outputs_prefix=f"{INTEGRATION_CONTEXT_NAME}.Indicators",
        outputs_key_field="domain",
        readable_output=readable_output,
        raw_response=indicators_list
    )


def reset_last_run():
    """
    Reset the last run from the integration context
    """
    demisto.setIntegrationContext({})
    return CommandResults(readable_output='Fetch history deleted successfully')


def main() -> None:
    """
    main function, parses params and runs command functions
    """
    command = demisto.command()
    args = demisto.args()
    username = demisto.params().get("dt_api_username")
    api_key = demisto.params().get("dt_api_key")
    verify_certificate = not demisto.params().get("insecure", False)
    proxy = demisto.params().get("proxy", False)
    tlp_color = demisto.params().get("tlp_color")
    tags = argToList(demisto.params().get("feedTags"))
    risk_score_ranges = argToList(demisto.params().get("risk_score_ranges"))
    include_domain_data = demisto.params().get("include_domain_data")
    new_domains = demisto.params().get("new_domains")
    changed_domains = demisto.params().get("changed_domains")
    blocked_domains = demisto.params().get("blocked_domains")
    try:
        client = Client(
            username,
            api_key,
            new_domains,
            changed_domains,
            blocked_domains,
            tags,
            risk_score_ranges,
            tlp_color,
            include_domain_data,
            verify=verify_certificate,
            proxy=proxy,
        )
        commands = {
            "domaintools-iris-detect-get-new-domains": domaintools_iris_detect_get_new_domains,
            "domaintools-iris-detect-get-watched-domains": domaintools_iris_detect_get_watched_domains,
            "domaintools-iris-detect-get-ignored-domains": domaintools_iris_detect_get_ignored_domains,
            "domaintools-iris-detect-get-escalated-domains": domaintools_iris_detect_get_escalated_domains,
            "domaintools-iris-detect-get-blocklist-domains": domaintools_iris_detect_get_blocklist_domains,
            "domaintools-iris-detect-get-monitors-list": domaintools_iris_detect_get_monitors_list,
            "domaintools-iris-detect-escalate-domains": domaintools_iris_detect_escalate_domains,
            "domaintools-iris-detect-blocklist-domains": domaintools_iris_detect_blocklist_domains,
            "domaintools-iris-detect-watch-domains": domaintools_iris_detect_watch_domains,
            "domaintools-iris-detect-ignore-domains": domaintools_iris_detect_ignore_domains,
        }
        demisto.debug(f"Command being called is {demisto.command()}")
        if demisto.command() == "test-module":
            result = module_test(client)
            return_results(result)
        elif command in commands:
            return_results(commands[command](client, args))
        elif demisto.command() == "fetch-indicators":
            fetch_domains(client=client)
        # elif demisto.command() == "fetch-incidents":
        #     fetch_domains(client=client)
        else:
            raise NotImplementedError
    except Exception as err:
        return_error(
            f"Failed to execute {demisto.command()} command.\nError:\n{str(err)}"
        )


""" ENTRY POINT """

if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
